import { 
  VideoProject, 
  InsertVideoProject, 
  Caption, 
  InsertCaption,
  Translation,
  InsertTranslation,
  CaptionStyle,
  InsertCaptionStyle,
  User, 
  InsertUser 
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Video project methods
  createVideoProject(project: InsertVideoProject): Promise<VideoProject>;
  getVideoProject(id: number): Promise<VideoProject | undefined>;
  getAllVideoProjects(): Promise<VideoProject[]>;
  updateVideoProjectStatus(id: number, status: string): Promise<VideoProject | undefined>;

  // Caption methods
  createCaption(caption: InsertCaption): Promise<Caption>;
  getCaptionsByProject(projectId: number): Promise<Caption[]>;
  updateCaption(id: number, updates: Partial<Caption>): Promise<Caption | undefined>;
  deleteCaption(id: number): Promise<boolean>;

  // Translation methods
  createTranslation(translation: InsertTranslation): Promise<Translation>;
  getTranslationsByCaption(captionId: number): Promise<Translation[]>;
  getTranslationsByProjectAndLanguage(projectId: number, language: string): Promise<Translation[]>;

  // Caption style methods
  createOrUpdateCaptionStyle(style: InsertCaptionStyle): Promise<CaptionStyle>;
  getCaptionStyleByProject(projectId: number): Promise<CaptionStyle | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private videoProjects: Map<number, VideoProject>;
  private captions: Map<number, Caption>;
  private translations: Map<number, Translation>;
  private captionStyles: Map<number, CaptionStyle>;
  
  private currentUserId: number;
  private currentProjectId: number;
  private currentCaptionId: number;
  private currentTranslationId: number;
  private currentStyleId: number;

  constructor() {
    this.users = new Map();
    this.videoProjects = new Map();
    this.captions = new Map();
    this.translations = new Map();
    this.captionStyles = new Map();
    
    this.currentUserId = 1;
    this.currentProjectId = 1;
    this.currentCaptionId = 1;
    this.currentTranslationId = 1;
    this.currentStyleId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Video project methods
  async createVideoProject(insertProject: InsertVideoProject): Promise<VideoProject> {
    const id = this.currentProjectId++;
    const project: VideoProject = { 
      ...insertProject, 
      id,
      duration: insertProject.duration || null,
      status: insertProject.status || "uploaded",
      createdAt: new Date()
    };
    this.videoProjects.set(id, project);
    return project;
  }

  async getVideoProject(id: number): Promise<VideoProject | undefined> {
    return this.videoProjects.get(id);
  }

  async getAllVideoProjects(): Promise<VideoProject[]> {
    return Array.from(this.videoProjects.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async updateVideoProjectStatus(id: number, status: string): Promise<VideoProject | undefined> {
    const project = this.videoProjects.get(id);
    if (project) {
      const updated = { ...project, status };
      this.videoProjects.set(id, updated);
      return updated;
    }
    return undefined;
  }

  // Caption methods
  async createCaption(insertCaption: InsertCaption): Promise<Caption> {
    const id = this.currentCaptionId++;
    const caption: Caption = { 
      ...insertCaption, 
      id,
      language: insertCaption.language || "auto",
      confidence: insertCaption.confidence || null
    };
    this.captions.set(id, caption);
    return caption;
  }

  async getCaptionsByProject(projectId: number): Promise<Caption[]> {
    return Array.from(this.captions.values())
      .filter(caption => caption.projectId === projectId)
      .sort((a, b) => a.startTime - b.startTime);
  }

  async updateCaption(id: number, updates: Partial<Caption>): Promise<Caption | undefined> {
    const caption = this.captions.get(id);
    if (caption) {
      const updated = { ...caption, ...updates };
      this.captions.set(id, updated);
      return updated;
    }
    return undefined;
  }

  async deleteCaption(id: number): Promise<boolean> {
    return this.captions.delete(id);
  }

  // Translation methods
  async createTranslation(insertTranslation: InsertTranslation): Promise<Translation> {
    const id = this.currentTranslationId++;
    const translation: Translation = { 
      ...insertTranslation, 
      id,
      confidence: insertTranslation.confidence || null
    };
    this.translations.set(id, translation);
    return translation;
  }

  async getTranslationsByCaption(captionId: number): Promise<Translation[]> {
    return Array.from(this.translations.values())
      .filter(translation => translation.captionId === captionId);
  }

  async getTranslationsByProjectAndLanguage(projectId: number, language: string): Promise<Translation[]> {
    const projectCaptions = await this.getCaptionsByProject(projectId);
    const captionIds = projectCaptions.map(c => c.id);
    
    return Array.from(this.translations.values())
      .filter(translation => 
        captionIds.includes(translation.captionId) && 
        translation.language === language
      );
  }

  // Caption style methods
  async createOrUpdateCaptionStyle(insertStyle: InsertCaptionStyle): Promise<CaptionStyle> {
    const existing = Array.from(this.captionStyles.values())
      .find(style => style.projectId === insertStyle.projectId);
    
    if (existing) {
      const updated = { ...existing, ...insertStyle };
      this.captionStyles.set(existing.id, updated);
      return updated;
    } else {
      const id = this.currentStyleId++;
      const style: CaptionStyle = { 
        ...insertStyle, 
        id,
        fontFamily: insertStyle.fontFamily || "Inter",
        fontSize: insertStyle.fontSize || "medium",
        textColor: insertStyle.textColor || "#ffffff",
        backgroundColor: insertStyle.backgroundColor || "#000000",
        bold: insertStyle.bold ?? false,
        italic: insertStyle.italic ?? false,
        shadow: insertStyle.shadow ?? true,
        outline: insertStyle.outline ?? false,
        glow: insertStyle.glow ?? false,
        position: insertStyle.position || "bottom",
        alignment: insertStyle.alignment || "center"
      };
      this.captionStyles.set(id, style);
      return style;
    }
  }

  async getCaptionStyleByProject(projectId: number): Promise<CaptionStyle | undefined> {
    return Array.from(this.captionStyles.values())
      .find(style => style.projectId === projectId);
  }
}

export const storage = new MemStorage();
