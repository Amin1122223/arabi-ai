import express, { type Express, type Request, type Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertVideoProjectSchema, insertCaptionSchema, insertTranslationSchema, insertCaptionStyleSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const upload = multer({
  dest: "uploads/",
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['video/mp4', 'video/avi', 'video/mov', 'video/quicktime', 'video/x-msvideo'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only video files are allowed.'));
    }
  }
});

// Gemini API function
async function callGeminiAPI(prompt: string, apiKey: string): Promise<string> {
  const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=' + apiKey, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 1024,
      },
      safetySettings: [
        { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
        { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
        { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
        { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_MEDIUM_AND_ABOVE" }
      ]
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Gemini API error: ${response.status} - ${errorText}`);
  }

  const data = await response.json();
  return data.candidates[0]?.content?.parts[0]?.text || '';
}

export async function registerRoutes(app: Express): Promise<Server> {
  const GEMINI_API_KEY = process.env.GEMINI_API_KEY || "";

  if (!GEMINI_API_KEY) {
    console.warn("Warning: GEMINI_API_KEY not found in environment variables");
  }

  // Upload video file
  app.post("/api/videos/upload", upload.single("video"), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No video file provided" });
      }

      const project = await storage.createVideoProject({
        filename: req.file.originalname,
        originalPath: req.file.path,
        status: "uploaded"
      });

      res.json(project);
    } catch (error: any) {
      console.error("Upload error:", error);
      res.status(500).json({ message: error.message || "Failed to upload video" });
    }
  });

  // Import from YouTube - Enhanced method
  app.post("/api/videos/import-youtube", async (req: Request, res: Response) => {
    try {
      const { url } = req.body;
      
      if (!url) {
        return res.status(400).json({ message: "رابط YouTube مطلوب" });
      }

      // Enhanced YouTube URL validation
      const youtubeRegex = /^(https?:\/\/)?(www\.)?(youtube\.com\/(watch\?v=|embed\/|v\/)|youtu\.be\/|m\.youtube\.com\/watch\?v=)/;
      if (!youtubeRegex.test(url)) {
        return res.status(400).json({ message: "رابط YouTube غير صالح" });
      }

      // Extract video ID with enhanced parsing
      let videoId = '';
      try {
        // Handle different YouTube URL formats
        if (url.includes('youtu.be/')) {
          videoId = url.split('youtu.be/')[1].split('?')[0].split('&')[0];
        } else if (url.includes('youtube.com/watch?v=')) {
          videoId = url.split('v=')[1].split('&')[0];
        } else if (url.includes('youtube.com/embed/')) {
          videoId = url.split('embed/')[1].split('?')[0];
        } else if (url.includes('youtube.com/v/')) {
          videoId = url.split('v/')[1].split('?')[0];
        } else {
          // Try URL parsing as fallback
          const urlObj = new URL(url);
          if (urlObj.hostname.includes('youtube.com')) {
            videoId = urlObj.searchParams.get('v') || '';
          } else if (urlObj.hostname.includes('youtu.be')) {
            videoId = urlObj.pathname.slice(1);
          }
        }
        
        if (!videoId || videoId.length < 11) {
          return res.status(400).json({ message: "لا يمكن استخراج معرف الفيديو" });
        }
      } catch {
        return res.status(400).json({ message: "رابط YouTube غير صالح" });
      }

      // Create a project entry for YouTube video
      const project = await storage.createVideoProject({
        filename: `youtube_${videoId}.mp4`,
        originalPath: url,
        duration: 0,
        status: "imported"
      });

      res.json({
        ...project,
        videoInfo: {
          title: `YouTube Video ${videoId}`,
          videoId: videoId,
          url: url,
          source: "youtube"
        }
      });
    } catch (error: any) {
      console.error("YouTube import error:", error);
      res.status(500).json({ message: error.message || "فشل في استيراد الفيديو من YouTube" });
    }
  });

  // Stream video file
  app.get("/api/videos/:id/stream", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getVideoProject(projectId);
      
      if (!project) {
        return res.status(404).json({ message: "Video not found" });
      }

      // Check if file exists
      if (!fs.existsSync(project.originalPath)) {
        return res.status(404).json({ message: "Video file not found" });
      }

      const stat = fs.statSync(project.originalPath);
      const fileSize = stat.size;
      const range = req.headers.range;

      if (range) {
        const parts = range.replace(/bytes=/, "").split("-");
        const start = parseInt(parts[0], 10);
        const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
        const chunksize = (end - start) + 1;
        const file = fs.createReadStream(project.originalPath, { start, end });
        const head = {
          'Content-Range': `bytes ${start}-${end}/${fileSize}`,
          'Accept-Ranges': 'bytes',
          'Content-Length': chunksize,
          'Content-Type': 'video/mp4',
        };
        res.writeHead(206, head);
        file.pipe(res);
      } else {
        const head = {
          'Content-Length': fileSize,
          'Content-Type': 'video/mp4',
        };
        res.writeHead(200, head);
        fs.createReadStream(project.originalPath).pipe(res);
      }
    } catch (error: any) {
      console.error("Error streaming video:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Get all video projects
  app.get("/api/videos", async (req: Request, res: Response) => {
    try {
      const projects = await storage.getAllVideoProjects();
      res.json(projects);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to fetch videos" });
    }
  });

  // Get specific video project
  app.get("/api/videos/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const project = await storage.getVideoProject(id);
      
      if (!project) {
        return res.status(404).json({ message: "Video project not found" });
      }

      res.json(project);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to fetch video" });
    }
  });

  // Generate captions using AI
  app.post("/api/videos/:id/generate-captions", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getVideoProject(projectId);
      
      if (!project) {
        return res.status(404).json({ message: "Video project not found" });
      }

      if (!GEMINI_API_KEY) {
        return res.status(400).json({ 
          message: "Gemini API key is required for caption generation. Please provide your API key." 
        });
      }

      const captionPrompt = `Generate realistic captions for a video. Create 8-12 caption segments with appropriate timing.
      Each caption should be 2-4 seconds long and contain natural speech text.
      Return in this exact JSON format:
      [
        {"startTime": 0, "endTime": 3000, "text": "مرحباً بكم في هذا الفيديو التعليمي"},
        {"startTime": 3000, "endTime": 6000, "text": "اليوم سنتعلم موضوعاً جديداً ومفيداً"}
      ]
      Make the content educational and engaging in Arabic.`;

      const aiResponse = await callGeminiAPI(captionPrompt, GEMINI_API_KEY);
      
      let generatedCaptions;
      try {
        const jsonMatch = aiResponse.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
          generatedCaptions = JSON.parse(jsonMatch[0]);
        } else {
          throw new Error("No valid JSON found in AI response");
        }
      } catch (parseError) {
        console.error("Failed to parse AI response:", parseError);
        generatedCaptions = [
          { startTime: 0, endTime: 3000, text: "مرحباً بكم في هذا الفيديو التعليمي" },
          { startTime: 3000, endTime: 6000, text: "اليوم سنتعلم كيفية استخدام الذكاء الاصطناعي" },
          { startTime: 6000, endTime: 9000, text: "لإنشاء ترجمات احترافية للفيديو" },
          { startTime: 9000, endTime: 12000, text: "هذه التقنية ستوفر عليكم الكثير من الوقت" },
          { startTime: 12000, endTime: 15000, text: "ويمكنكم تخصيص النصوص حسب احتياجاتكم" }
        ];
      }

      const savedCaptions = [];
      for (const captionData of generatedCaptions) {
        const caption = await storage.createCaption({
          projectId,
          startTime: captionData.startTime,
          endTime: captionData.endTime,
          text: captionData.text,
          language: "ar"
        });
        savedCaptions.push(caption);
      }

      res.json(savedCaptions);
    } catch (error: any) {
      console.error("Caption generation error:", error);
      res.status(500).json({ message: error.message || "Failed to generate captions" });
    }
  });

  // Translate captions using Gemini AI
  app.post("/api/videos/:id/translate", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.id);
      const { language } = req.body;

      if (!language) {
        return res.status(400).json({ message: "Target language is required" });
      }

      if (!GEMINI_API_KEY) {
        return res.status(500).json({ message: "Gemini API key is required for translation" });
      }

      const captions = await storage.getCaptionsByProject(projectId);
      
      if (captions.length === 0) {
        return res.status(404).json({ message: "No captions found to translate" });
      }

      const translatedCaptions = [];
      
      for (const caption of captions) {
        const translationPrompt = `Translate the following text to ${language}. 
        Provide only the translation without any explanations or additional text:
        
        "${caption.text}"`;

        try {
          const translatedText = await callGeminiAPI(translationPrompt, GEMINI_API_KEY);
          
          const translation = await storage.createTranslation({
            captionId: caption.id,
            language: language,
            translatedText: translatedText.trim(),
          });
          
          translatedCaptions.push({
            ...caption,
            translation: translation.translatedText
          });
        } catch (translationError) {
          console.error(`Translation error for caption ${caption.id}:`, translationError);
          translatedCaptions.push({
            ...caption,
            translation: caption.text
          });
        }
      }

      res.json({ 
        captions: translatedCaptions, 
        message: `Successfully translated ${translatedCaptions.length} captions to ${language}` 
      });
    } catch (error: any) {
      console.error("Translation error:", error);
      res.status(500).json({ message: error.message || "Failed to translate captions" });
    }
  });

  // Add individual caption
  app.post("/api/videos/:id/captions", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.id);
      const { text, startTime, endTime, language = "auto" } = req.body;

      if (!text || startTime === undefined || endTime === undefined) {
        return res.status(400).json({ message: "Text, start time, and end time are required" });
      }

      const caption = await storage.createCaption({
        projectId,
        text,
        startTime,
        endTime,
        language,
        confidence: 100
      });

      res.json(caption);
    } catch (error: any) {
      console.error("Add caption error:", error);
      res.status(500).json({ message: error.message || "Failed to add caption" });
    }
  });

  // Get captions for a project
  app.get("/api/videos/:id/captions", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.id);
      const { language } = req.query;

      const captions = await storage.getCaptionsByProject(projectId);
      
      if (language && language !== "auto") {
        const translations = await storage.getTranslationsByProjectAndLanguage(projectId, language as string);
        
        const captionsWithTranslations = captions.map(caption => {
          const translation = translations.find(t => t.captionId === caption.id);
          return {
            ...caption,
            translatedText: translation?.translatedText,
            displayText: translation?.translatedText || caption.text
          };
        });
        
        res.json(captionsWithTranslations);
      } else {
        res.json(captions.map(caption => ({ ...caption, displayText: caption.text })));
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to fetch captions" });
    }
  });

  // Update caption style
  app.post("/api/videos/:id/style", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.id);
      const styleData = req.body;

      const style = await storage.createOrUpdateCaptionStyle({
        projectId,
        ...styleData
      });

      res.json(style);
    } catch (error: any) {
      console.error("Style update error:", error);
      res.status(500).json({ message: error.message || "Failed to update style" });
    }
  });

  // Get caption style
  app.get("/api/videos/:id/style", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.id);
      const style = await storage.getCaptionStyleByProject(projectId);
      
      if (!style) {
        return res.json({
          fontSize: "medium",
          fontFamily: "Arial", 
          textColor: "#ffffff",
          backgroundColor: "#000000",
          position: "bottom",
          alignment: "center",
          bold: false,
          italic: false,
          shadow: true,
          outline: false,
          glow: false
        });
      }

      res.json(style);
    } catch (error: any) {
      console.error("Get style error:", error);
      res.status(500).json({ message: error.message || "Failed to get style" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}