import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const videoProjects = pgTable("video_projects", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  originalPath: text("original_path").notNull(),
  duration: integer("duration"), // in seconds
  status: text("status").notNull().default("uploaded"), // uploaded, processing, completed, error
  createdAt: timestamp("created_at").defaultNow(),
});

export const captions = pgTable("captions", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  text: text("text").notNull(),
  startTime: integer("start_time").notNull(), // in milliseconds
  endTime: integer("end_time").notNull(), // in milliseconds
  language: text("language").notNull().default("auto"),
  confidence: integer("confidence"), // 0-100
});

export const translations = pgTable("translations", {
  id: serial("id").primaryKey(),
  captionId: integer("caption_id").notNull(),
  language: text("language").notNull(),
  translatedText: text("translated_text").notNull(),
  confidence: integer("confidence"), // 0-100
});

export const captionStyles = pgTable("caption_styles", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  fontFamily: text("font_family").notNull().default("Inter"),
  fontSize: text("font_size").notNull().default("medium"),
  textColor: text("text_color").notNull().default("#ffffff"),
  backgroundColor: text("background_color").default("#000000"),
  bold: boolean("bold").default(false),
  italic: boolean("italic").default(false),
  shadow: boolean("shadow").default(true),
  outline: boolean("outline").default(false),
  glow: boolean("glow").default(false),
  position: text("position").notNull().default("bottom"), // top, middle, bottom
  alignment: text("alignment").notNull().default("center"), // left, center, right
});

export const insertVideoProjectSchema = createInsertSchema(videoProjects).omit({
  id: true,
  createdAt: true,
});

export const insertCaptionSchema = createInsertSchema(captions).omit({
  id: true,
});

export const insertTranslationSchema = createInsertSchema(translations).omit({
  id: true,
});

export const insertCaptionStyleSchema = createInsertSchema(captionStyles).omit({
  id: true,
});

export type VideoProject = typeof videoProjects.$inferSelect;
export type InsertVideoProject = z.infer<typeof insertVideoProjectSchema>;
export type Caption = typeof captions.$inferSelect;
export type InsertCaption = z.infer<typeof insertCaptionSchema>;
export type Translation = typeof translations.$inferSelect;
export type InsertTranslation = z.infer<typeof insertTranslationSchema>;
export type CaptionStyle = typeof captionStyles.$inferSelect;
export type InsertCaptionStyle = z.infer<typeof insertCaptionStyleSchema>;

// Keep existing user schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
