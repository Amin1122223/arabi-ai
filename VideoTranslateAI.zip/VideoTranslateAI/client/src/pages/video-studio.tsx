import { useState } from "react";
import { VideoUpload } from "@/components/video-upload";
import { CapCutEditor } from "@/components/capcut-editor";
import { Video, Settings, CloudUpload, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { VideoProject } from "@shared/schema";

export default function VideoStudio() {
  const [selectedProject, setSelectedProject] = useState<VideoProject | null>(null);

  const { data: projects } = useQuery<VideoProject[]>({
    queryKey: ["/api/videos"],
  });

  return (
    <div className="min-h-screen bg-background text-foreground animate-fade-in">
      {/* Enhanced Header with Glass Effect */}
      <header className="glass-effect border-b border-border px-6 py-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-pink-500/10"></div>
        <div className="relative flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-4 animate-slide-in">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 rounded-xl flex items-center justify-center neon-glow-blue animate-pulse-glow">
              <Sparkles className="text-white text-xl" />
            </div>
            <div>
              <h1 className="text-2xl font-bold gradient-text">استوديو الترجمة المتقدم</h1>
              <p className="text-sm text-muted-foreground">محرر فيديو احترافي مع ترجمة ذكية حقيقية</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Button className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 font-medium neon-glow-cyan">
              <CloudUpload className="mr-2 h-4 w-4" />
              مشروع جديد
            </Button>
            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground glass-effect">
              <Settings className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Enhanced Main Workspace */}
      <main className="flex h-[calc(100vh-88px)] relative">
        {/* Animated Background */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-20 left-20 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl animate-float"></div>
          <div className="absolute top-40 right-20 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl animate-float" style={{animationDelay: '2s'}}></div>
          <div className="absolute bottom-20 left-1/2 w-96 h-96 bg-pink-500 rounded-full mix-blend-multiply filter blur-xl animate-float" style={{animationDelay: '4s'}}></div>
        </div>

        {/* Advanced Video Editor */}
        <div className="flex-1 relative z-10">
          {!selectedProject ? (
            <div className="h-full p-6">
              <VideoUpload onProjectCreated={setSelectedProject} />
            </div>
          ) : (
            <CapCutEditor project={selectedProject} />
          )}
        </div>
      </main>
    </div>
  );
}
