export function formatTime(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

export function formatDuration(milliseconds: number): string {
  const seconds = Math.floor(milliseconds / 1000);
  return formatTime(seconds);
}

export function validateVideoFile(file: File): { valid: boolean; error?: string } {
  const allowedTypes = ['video/mp4', 'video/avi', 'video/mov', 'video/quicktime', 'video/x-msvideo'];
  const maxSize = 100 * 1024 * 1024; // 100MB

  if (!allowedTypes.includes(file.type)) {
    return {
      valid: false,
      error: 'Invalid file type. Please upload MP4, AVI, or MOV files only.',
    };
  }

  if (file.size > maxSize) {
    return {
      valid: false,
      error: 'File too large. Please upload files smaller than 100MB.',
    };
  }

  return { valid: true };
}

export function getVideoThumbnail(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    video.onloadedmetadata = () => {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      video.currentTime = 1; // Seek to 1 second
    };

    video.onseeked = () => {
      if (ctx) {
        ctx.drawImage(video, 0, 0);
        const dataURL = canvas.toDataURL('image/jpeg', 0.8);
        resolve(dataURL);
      } else {
        reject(new Error('Failed to get canvas context'));
      }
    };

    video.onerror = () => {
      reject(new Error('Failed to load video'));
    };

    video.src = URL.createObjectURL(file);
  });
}

export const SUPPORTED_LANGUAGES = [
  { code: 'auto', name: 'Auto-detect', flag: '🌐' },
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'ar', name: 'Arabic', flag: '🇸🇦' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸' },
  { code: 'fr', name: 'French', flag: '🇫🇷' },
  { code: 'de', name: 'German', flag: '🇩🇪' },
  { code: 'zh', name: 'Chinese', flag: '🇨🇳' },
  { code: 'ja', name: 'Japanese', flag: '🇯🇵' },
  { code: 'ko', name: 'Korean', flag: '🇰🇷' },
  { code: 'pt', name: 'Portuguese', flag: '🇵🇹' },
  { code: 'ru', name: 'Russian', flag: '🇷🇺' },
  { code: 'it', name: 'Italian', flag: '🇮🇹' },
  { code: 'nl', name: 'Dutch', flag: '🇳🇱' },
  { code: 'tr', name: 'Turkish', flag: '🇹🇷' },
];

export const FONT_PRESETS = [
  { name: 'Modern', fontFamily: 'Inter', fontSize: 'large', bold: false },
  { name: 'Bold Impact', fontFamily: 'Montserrat', fontSize: 'x-large', bold: true },
  { name: 'Classic', fontFamily: 'Arial', fontSize: 'medium', bold: false },
  { name: 'Elegant', fontFamily: 'Open Sans', fontSize: 'large', bold: false },
];

export const COLOR_PRESETS = [
  { name: 'Classic White', textColor: '#ffffff', backgroundColor: 'rgba(0,0,0,0.8)' },
  { name: 'Bright Yellow', textColor: '#ffff00', backgroundColor: 'rgba(0,0,0,0.8)' },
  { name: 'Electric Blue', textColor: '#00bfff', backgroundColor: 'rgba(0,0,0,0.8)' },
  { name: 'Vibrant Green', textColor: '#00ff00', backgroundColor: 'rgba(0,0,0,0.8)' },
  { name: 'Hot Pink', textColor: '#ff1493', backgroundColor: 'rgba(0,0,0,0.8)' },
];
