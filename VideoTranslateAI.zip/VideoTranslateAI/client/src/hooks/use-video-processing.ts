import { useState, useCallback } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { VideoProject } from '@shared/schema';

interface UseVideoProcessingOptions {
  onSuccess?: (result: any) => void;
  onError?: (error: Error) => void;
}

export function useVideoProcessing(options: UseVideoProcessingOptions = {}) {
  const [processingStatus, setProcessingStatus] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      setProcessingStatus('Uploading video...');
      setProgress(25);

      const formData = new FormData();
      formData.append('video', file);

      const response = await fetch('/api/videos/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Upload failed');
      }

      setProgress(100);
      return response.json();
    },
    onSuccess: (project: VideoProject) => {
      setProcessingStatus(null);
      setProgress(0);
      toast({
        title: 'Upload Complete',
        description: 'Your video has been uploaded successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
      options.onSuccess?.(project);
    },
    onError: (error: Error) => {
      setProcessingStatus(null);
      setProgress(0);
      toast({
        variant: 'destructive',
        title: 'Upload Failed',
        description: error.message,
      });
      options.onError?.(error);
    },
  });

  const generateCaptionsMutation = useMutation({
    mutationFn: async ({
      projectId,
      sourceLanguage,
      targetLanguage,
    }: {
      projectId: number;
      sourceLanguage: string;
      targetLanguage: string;
    }) => {
      setProcessingStatus('Analyzing audio...');
      setProgress(20);

      // Simulate progress updates
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 1000);

      try {
        const response = await apiRequest('POST', `/api/videos/${projectId}/generate-captions`, {
          sourceLanguage,
          targetLanguage,
        });

        clearInterval(progressInterval);
        setProgress(100);

        const result = await response.json();
        return result;
      } catch (error) {
        clearInterval(progressInterval);
        throw error;
      }
    },
    onSuccess: (result) => {
      setProcessingStatus(null);
      setProgress(0);
      toast({
        title: 'Captions Generated',
        description: 'Your video captions have been generated successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
      options.onSuccess?.(result);
    },
    onError: (error: Error) => {
      setProcessingStatus(null);
      setProgress(0);
      toast({
        variant: 'destructive',
        title: 'Caption Generation Failed',
        description: error.message,
      });
      options.onError?.(error);
    },
  });

  const translateCaptionsMutation = useMutation({
    mutationFn: async ({
      captionIds,
      targetLanguage,
    }: {
      captionIds: number[];
      targetLanguage: string;
    }) => {
      setProcessingStatus('Translating captions...');
      setProgress(30);

      const response = await apiRequest('POST', '/api/captions/translate', {
        captionIds,
        targetLanguage,
      });

      setProgress(100);
      return response.json();
    },
    onSuccess: (result) => {
      setProcessingStatus(null);
      setProgress(0);
      toast({
        title: 'Translation Complete',
        description: 'Your captions have been translated successfully.',
      });
      options.onSuccess?.(result);
    },
    onError: (error: Error) => {
      setProcessingStatus(null);
      setProgress(0);
      toast({
        variant: 'destructive',
        title: 'Translation Failed',
        description: error.message,
      });
      options.onError?.(error);
    },
  });

  const uploadVideo = useCallback((file: File) => {
    uploadMutation.mutate(file);
  }, [uploadMutation]);

  const generateCaptions = useCallback(
    (projectId: number, sourceLanguage: string, targetLanguage: string) => {
      generateCaptionsMutation.mutate({ projectId, sourceLanguage, targetLanguage });
    },
    [generateCaptionsMutation]
  );

  const translateCaptions = useCallback(
    (captionIds: number[], targetLanguage: string) => {
      translateCaptionsMutation.mutate({ captionIds, targetLanguage });
    },
    [translateCaptionsMutation]
  );

  return {
    // State
    processingStatus,
    progress,
    isProcessing: uploadMutation.isPending || generateCaptionsMutation.isPending || translateCaptionsMutation.isPending,
    
    // Actions
    uploadVideo,
    generateCaptions,
    translateCaptions,
    
    // Mutation states
    isUploading: uploadMutation.isPending,
    isGeneratingCaptions: generateCaptionsMutation.isPending,
    isTranslating: translateCaptionsMutation.isPending,
  };
}
