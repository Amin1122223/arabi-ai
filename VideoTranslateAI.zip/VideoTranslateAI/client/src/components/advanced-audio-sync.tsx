import { useState, useEffect, useRef, useCallback } from "react";
import { VideoProject, Caption } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { 
  Volume2, VolumeX, BarChart3, Mic, Languages, 
  RefreshCw, Clock, Eye, Zap, Settings, Activity,
  Waves, Target, AlertCircle, CheckCircle
} from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AdvancedAudioSyncProps {
  project: VideoProject;
  captions: Caption[];
  currentTime: number;
  isPlaying: boolean;
  onTimeUpdate: (time: number) => void;
}

interface AudioAnalysis {
  volume: number;
  frequency: Float32Array;
  speechConfidence: number;
  speechStart: number | null;
  speechEnd: number | null;
  dominantFrequency: number;
  energyDistribution: number[];
}

interface SyncSuggestion {
  captionId: number;
  suggestedOffset: number;
  confidence: number;
  reason: string;
}

export function AdvancedAudioSync({ 
  project, 
  captions, 
  currentTime, 
  isPlaying,
  onTimeUpdate 
}: AdvancedAudioSyncProps) {
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [analyzer, setAnalyzer] = useState<AnalyserNode | null>(null);
  const [audioData, setAudioData] = useState<AudioAnalysis>({
    volume: 0,
    frequency: new Float32Array(0),
    speechConfidence: 0,
    speechStart: null,
    speechEnd: null,
    dominantFrequency: 0,
    energyDistribution: []
  });
  
  const [syncOffset, setSyncOffset] = useState(0);
  const [autoSync, setAutoSync] = useState(true);
  const [speechThreshold, setSpeechThreshold] = useState(30);
  const [visualMode, setVisualMode] = useState<'waveform' | 'spectrum' | 'speech'>('speech');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [syncSuggestions, setSyncSuggestions] = useState<SyncSuggestion[]>([]);
  const [realTimeMode, setRealTimeMode] = useState(true);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const speechHistoryRef = useRef<number[]>([]);
  const lastSpeechTimeRef = useRef<number>(0);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check if this is a YouTube video
  const isYouTubeVideo = project.originalPath?.includes('youtube.com') || project.originalPath?.includes('youtu.be');

  // Initialize advanced audio analysis
  useEffect(() => {
    if (!videoRef.current || isYouTubeVideo) return;

    const initAdvancedAudioAnalysis = async () => {
      try {
        setIsAnalyzing(true);
        const context = new (window.AudioContext || (window as any).webkitAudioContext)();
        const analyserNode = context.createAnalyser();
        
        // Enhanced settings for speech detection
        analyserNode.fftSize = 4096;
        analyserNode.smoothingTimeConstant = 0.3;
        analyserNode.minDecibels = -90;
        analyserNode.maxDecibels = -10;
        
        const source = context.createMediaElementSource(videoRef.current!);
        source.connect(analyserNode);
        analyserNode.connect(context.destination);
        
        setAudioContext(context);
        setAnalyzer(analyserNode);
        setIsAnalyzing(false);
        
        toast({
          title: "تم تفعيل تحليل الصوت",
          description: "نظام كشف الكلام جاهز للعمل",
        });
      } catch (error) {
        console.warn('Advanced audio analysis not available:', error);
        setIsAnalyzing(false);
        toast({
          variant: "destructive",
          title: "تحذير",
          description: "تحليل الصوت غير متاح في هذا المتصفح",
        });
      }
    };

    initAdvancedAudioAnalysis();

    return () => {
      if (audioContext) {
        audioContext.close();
      }
    };
  }, [project.id, isYouTubeVideo, toast]);

  // Advanced audio analysis with speech detection
  const analyzeAdvancedAudio = useCallback(() => {
    if (!analyzer) return;

    const bufferLength = analyzer.frequencyBinCount;
    const frequencyData = new Float32Array(bufferLength);
    const timeDomainData = new Float32Array(bufferLength);
    
    analyzer.getFloatFrequencyData(frequencyData);
    analyzer.getFloatTimeDomainData(timeDomainData);

    // Calculate RMS volume
    let sum = 0;
    for (let i = 0; i < timeDomainData.length; i++) {
      sum += timeDomainData[i] * timeDomainData[i];
    }
    const volume = Math.sqrt(sum / timeDomainData.length) * 1000;

    // Speech detection algorithm
    // Human speech typically ranges from 85Hz to 8000Hz
    const speechRange = frequencyData.slice(8, 800); // Approximate speech frequency range
    const speechEnergy = speechRange.reduce((acc, val) => acc + (val > -60 ? Math.pow(10, val / 20) : 0), 0);
    const totalEnergy = frequencyData.reduce((acc, val) => acc + (val > -60 ? Math.pow(10, val / 20) : 0), 0);
    
    const speechRatio = totalEnergy > 0 ? (speechEnergy / totalEnergy) * 100 : 0;
    const speechConfidence = Math.min(100, Math.max(0, (speechRatio - 20) * 2));

    // Dominant frequency detection
    let maxIndex = 0;
    let maxValue = -Infinity;
    for (let i = 0; i < frequencyData.length; i++) {
      if (frequencyData[i] > maxValue) {
        maxValue = frequencyData[i];
        maxIndex = i;
      }
    }
    const dominantFrequency = (maxIndex * audioContext!.sampleRate) / (2 * bufferLength);

    // Energy distribution analysis
    const energyDistribution = [];
    const binSize = Math.floor(frequencyData.length / 8);
    for (let i = 0; i < 8; i++) {
      const start = i * binSize;
      const end = Math.min((i + 1) * binSize, frequencyData.length);
      const segmentEnergy = frequencyData.slice(start, end).reduce((acc, val) => 
        acc + (val > -60 ? Math.pow(10, val / 20) : 0), 0
      );
      energyDistribution.push(segmentEnergy);
    }

    // Speech timing detection
    const isSpeechDetected = speechConfidence > speechThreshold && volume > 5;
    let speechStart = audioData.speechStart;
    let speechEnd = audioData.speechEnd;

    if (isSpeechDetected && speechStart === null) {
      speechStart = currentTime;
    } else if (!isSpeechDetected && speechStart !== null) {
      speechEnd = currentTime;
      lastSpeechTimeRef.current = currentTime;
    }

    // Keep speech history for pattern analysis
    speechHistoryRef.current.push(speechConfidence);
    if (speechHistoryRef.current.length > 100) {
      speechHistoryRef.current.shift();
    }

    setAudioData({
      volume,
      frequency: frequencyData,
      speechConfidence,
      speechStart,
      speechEnd,
      dominantFrequency,
      energyDistribution
    });

    // Draw advanced visualization
    drawAdvancedVisualization(timeDomainData, frequencyData, speechConfidence);

    // Auto-sync logic
    if (autoSync && realTimeMode) {
      performAutoSync(speechConfidence, isSpeechDetected);
    }

    if (isPlaying) {
      animationRef.current = requestAnimationFrame(analyzeAdvancedAudio);
    }
  }, [analyzer, isPlaying, visualMode, speechThreshold, autoSync, realTimeMode, currentTime, audioData.speechStart]);

  // Advanced auto-sync algorithm
  const performAutoSync = (speechConfidence: number, isSpeechDetected: boolean) => {
    const currentCaption = getCurrentCaption();
    if (!currentCaption) return;

    const captionProgress = (currentTime - currentCaption.startTime) / (currentCaption.endTime - currentCaption.startTime);
    
    // If we're in the middle of a caption and speech is detected
    if (captionProgress > 0.1 && captionProgress < 0.9 && isSpeechDetected) {
      const avgSpeechConfidence = speechHistoryRef.current.slice(-20).reduce((a, b) => a + b, 0) / 20;
      
      // If speech confidence is consistently high, caption is likely well-synced
      if (avgSpeechConfidence > speechThreshold * 1.5) {
        // Caption seems well-synced, no adjustment needed
        return;
      }
    }

    // If no speech during caption time, suggest adjustment
    if (captionProgress > 0.5 && speechConfidence < speechThreshold * 0.5) {
      const suggestion: SyncSuggestion = {
        captionId: currentCaption.id,
        suggestedOffset: syncOffset + 200, // Delay caption
        confidence: 70,
        reason: "لا يوجد كلام مكتشف أثناء عرض النص"
      };
      
      setSyncSuggestions(prev => {
        const existing = prev.find(s => s.captionId === currentCaption.id);
        if (!existing) {
          return [...prev, suggestion];
        }
        return prev;
      });
    }
  };

  useEffect(() => {
    if (isPlaying && analyzer && realTimeMode) {
      analyzeAdvancedAudio();
    } else if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying, analyzer, analyzeAdvancedAudio, realTimeMode]);

  const drawAdvancedVisualization = (timeData: Float32Array, freqData: Float32Array, speechConf: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear with fade effect
    ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
    ctx.fillRect(0, 0, width, height);

    switch (visualMode) {
      case 'waveform':
        drawWaveform(ctx, timeData, width, height);
        break;
      case 'spectrum':
        drawSpectrum(ctx, freqData, width, height);
        break;
      case 'speech':
        drawSpeechAnalysis(ctx, freqData, speechConf, width, height);
        break;
    }

    // Speech confidence indicator
    if (speechConf > speechThreshold) {
      ctx.fillStyle = `rgba(255, 0, 0, ${speechConf / 100})`;
      ctx.fillRect(0, 0, width, 20);
      
      ctx.fillStyle = '#ffffff';
      ctx.font = '12px Arial';
      ctx.fillText(`🎙️ كلام: ${Math.round(speechConf)}%`, 10, 15);
    }

    // Volume indicator
    ctx.fillStyle = '#00ff88';
    ctx.fillRect(width - 60, 10, 50, 8);
    ctx.fillStyle = '#004422';
    ctx.fillRect(width - 60, 10, 50 * (audioData.volume / 50), 8);
  };

  const drawWaveform = (ctx: CanvasRenderingContext2D, data: Float32Array, width: number, height: number) => {
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#00ff88';
    ctx.beginPath();

    const sliceWidth = width / data.length;
    let x = 0;

    for (let i = 0; i < data.length; i++) {
      const v = (data[i] + 1) / 2;
      const y = v * height;

      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }

      x += sliceWidth;
    }

    ctx.stroke();
  };

  const drawSpectrum = (ctx: CanvasRenderingContext2D, data: Float32Array, width: number, height: number) => {
    const barWidth = width / data.length;
    let x = 0;

    for (let i = 0; i < data.length; i++) {
      const barHeight = ((data[i] + 140) / 140) * height;
      
      const hue = (i / data.length) * 360;
      ctx.fillStyle = `hsl(${hue}, 70%, 50%)`;
      ctx.fillRect(x, height - barHeight, barWidth, barHeight);

      x += barWidth;
    }
  };

  const drawSpeechAnalysis = (ctx: CanvasRenderingContext2D, data: Float32Array, speechConf: number, width: number, height: number) => {
    // Draw frequency bands relevant to speech
    const speechBands = [
      { start: 8, end: 40, color: '#ff6b6b', label: 'Bass' },
      { start: 40, end: 160, color: '#4ecdc4', label: 'Mid-Low' },
      { start: 160, end: 400, color: '#45b7d1', label: 'Mid' },
      { start: 400, end: 800, color: '#96ceb4', label: 'Mid-High' },
      { start: 800, end: 1600, color: '#feca57', label: 'High' },
    ];

    const bandWidth = width / speechBands.length;
    
    speechBands.forEach((band, index) => {
      const bandData = data.slice(band.start, band.end);
      const avgLevel = bandData.reduce((sum, val) => sum + (val > -60 ? Math.pow(10, val / 20) : 0), 0) / bandData.length;
      const barHeight = Math.min(height, avgLevel * height * 0.1);
      
      ctx.fillStyle = band.color;
      ctx.fillRect(index * bandWidth, height - barHeight, bandWidth - 2, barHeight);
      
      // Band label
      ctx.fillStyle = '#ffffff';
      ctx.font = '10px Arial';
      ctx.fillText(band.label, index * bandWidth + 5, height - 5);
    });

    // Speech confidence visualization
    ctx.fillStyle = `rgba(255, 255, 255, ${speechConf / 100})`;
    ctx.fillRect(0, height - 30, (speechConf / 100) * width, 30);
  };

  // Smart sync suggestions
  const applySyncSuggestion = async (suggestion: SyncSuggestion) => {
    setSyncOffset(suggestion.suggestedOffset);
    
    // Remove applied suggestion
    setSyncSuggestions(prev => prev.filter(s => s.captionId !== suggestion.captionId));
    
    toast({
      title: "تم تطبيق الاقتراح",
      description: `تم تعديل المزامنة بمقدار ${suggestion.suggestedOffset}ms`,
    });
  };

  // Find current caption with sync offset
  const getCurrentCaption = () => {
    const adjustedTime = currentTime + syncOffset;
    return captions.find(
      caption => adjustedTime >= caption.startTime && adjustedTime <= caption.endTime
    );
  };

  const formatTime = (ms: number) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    const milliseconds = Math.floor((ms % 1000) / 10);
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}.${milliseconds.toString().padStart(2, '0')}`;
  };

  const currentCaption = getCurrentCaption();

  return (
    <div className="space-y-4">
      {/* Advanced Audio Analysis Panel */}
      <Card className="glass-effect border-purple-500/30">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center justify-between">
            <div className="flex items-center">
              <Activity className="w-4 h-4 mr-2 text-purple-400" />
              تحليل الصوت المتقدم
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant={isAnalyzing ? "destructive" : "default"} className="text-xs">
                {isAnalyzing ? "جاري التحليل..." : "جاهز"}
              </Badge>
              <Switch
                checked={realTimeMode}
                onCheckedChange={setRealTimeMode}
                disabled={isAnalyzing}
              />
              <Label className="text-xs">مباشر</Label>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Visualization Mode Selector */}
          <div className="flex space-x-2">
            <Button
              variant={visualMode === 'waveform' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setVisualMode('waveform')}
              className="text-xs flex-1"
            >
              <Waves className="w-3 h-3 mr-1" />
              موجة
            </Button>
            <Button
              variant={visualMode === 'spectrum' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setVisualMode('spectrum')}
              className="text-xs flex-1"
            >
              <BarChart3 className="w-3 h-3 mr-1" />
              طيف
            </Button>
            <Button
              variant={visualMode === 'speech' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setVisualMode('speech')}
              className="text-xs flex-1"
            >
              <Mic className="w-3 h-3 mr-1" />
              كلام
            </Button>
          </div>

          {/* Advanced Visualization Canvas */}
          <div className="relative">
            <canvas
              ref={canvasRef}
              width={400}
              height={120}
              className="w-full h-30 bg-black rounded border border-purple-500/30"
            />
            
            {/* Real-time Audio Metrics */}
            <div className="absolute top-2 left-2 space-y-1">
              <div className="text-xs text-white bg-black/50 px-2 py-1 rounded">
                مستوى الصوت: {Math.round(audioData.volume)}%
              </div>
              <div className="text-xs text-white bg-black/50 px-2 py-1 rounded">
                ثقة الكلام: {Math.round(audioData.speechConfidence)}%
              </div>
              <div className="text-xs text-white bg-black/50 px-2 py-1 rounded">
                التردد المهيمن: {Math.round(audioData.dominantFrequency)}Hz
              </div>
            </div>

            {/* Speech Detection Indicator */}
            {audioData.speechConfidence > speechThreshold && (
              <div className="absolute top-2 right-2">
                <Badge className="bg-red-500 text-white animate-pulse">
                  <Mic className="w-3 h-3 mr-1" />
                  كلام مكتشف
                </Badge>
              </div>
            )}
          </div>

          {/* Speech Detection Threshold */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-xs">حد كشف الكلام</Label>
              <span className="text-xs font-mono">{speechThreshold}%</span>
            </div>
            <Slider
              value={[speechThreshold]}
              onValueChange={(value) => setSpeechThreshold(value[0])}
              min={10}
              max={80}
              step={5}
              className="w-full"
            />
          </div>
        </CardContent>
      </Card>

      {/* Smart Sync Suggestions */}
      {syncSuggestions.length > 0 && (
        <Card className="glass-effect border-yellow-500/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center">
              <Target className="w-4 h-4 mr-2 text-yellow-400" />
              اقتراحات المزامنة الذكية
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {syncSuggestions.map((suggestion, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-yellow-500/10 rounded-lg border border-yellow-500/30">
                <div className="flex-1">
                  <p className="text-sm font-medium">نص #{suggestion.captionId}</p>
                  <p className="text-xs text-muted-foreground">{suggestion.reason}</p>
                  <div className="flex items-center mt-1">
                    <Progress value={suggestion.confidence} className="w-16 h-1 mr-2" />
                    <span className="text-xs">{suggestion.confidence}% ثقة</span>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button
                    size="sm"
                    onClick={() => applySyncSuggestion(suggestion)}
                    className="text-xs"
                  >
                    تطبيق
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setSyncSuggestions(prev => prev.filter((_, i) => i !== index))}
                    className="text-xs"
                  >
                    تجاهل
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Advanced Sync Controls */}
      <Card className="glass-effect border-blue-500/30">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center justify-between">
            <div className="flex items-center">
              <RefreshCw className="w-4 h-4 mr-2 text-blue-400" />
              مزامنة متقدمة
            </div>
            <Switch
              checked={autoSync}
              onCheckedChange={setAutoSync}
            />
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs">إزاحة المزامنة</span>
              <span className="text-xs font-mono">{syncOffset > 0 ? '+' : ''}{syncOffset}ms</span>
            </div>
            <Slider
              value={[syncOffset]}
              onValueChange={(value) => setSyncOffset(value[0])}
              min={-5000}
              max={5000}
              step={25}
              className="w-full"
            />
          </div>

          <div className="grid grid-cols-4 gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSyncOffset(prev => prev - 250)}
              className="text-xs"
            >
              -250ms
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSyncOffset(prev => prev - 50)}
              className="text-xs"
            >
              -50ms
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSyncOffset(prev => prev + 50)}
              className="text-xs"
            >
              +50ms
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSyncOffset(prev => prev + 250)}
              className="text-xs"
            >
              +250ms
            </Button>
          </div>

          <Button
            variant="outline"
            onClick={() => setSyncOffset(0)}
            className="w-full text-xs"
          >
            إعادة تعيين المزامنة
          </Button>
        </CardContent>
      </Card>

      {/* Current Caption with Advanced Info */}
      {currentCaption && (
        <Card className="glass-effect border-green-500/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center justify-between">
              <div className="flex items-center">
                <Languages className="w-4 h-4 mr-2 text-green-400" />
                النص الحالي
              </div>
              <div className="flex items-center space-x-2">
                <Badge 
                  variant={audioData.speechConfidence > speechThreshold ? "default" : "secondary"}
                  className="text-xs"
                >
                  {audioData.speechConfidence > speechThreshold ? (
                    <CheckCircle className="w-3 h-3 mr-1" />
                  ) : (
                    <AlertCircle className="w-3 h-3 mr-1" />
                  )}
                  {audioData.speechConfidence > speechThreshold ? "متزامن" : "غير متزامن"}
                </Badge>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="p-3 bg-black/30 rounded-lg border border-green-500/30">
                <p className="text-lg font-medium text-center">
                  {currentCaption.text}
                </p>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-muted-foreground">وقت البداية:</span>
                  <div className="font-mono">{formatTime(currentCaption.startTime)}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">وقت النهاية:</span>
                  <div className="font-mono">{formatTime(currentCaption.endTime)}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">المدة:</span>
                  <div className="font-mono">{formatTime(currentCaption.endTime - currentCaption.startTime)}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">الإزاحة:</span>
                  <div className="font-mono">{syncOffset}ms</div>
                </div>
              </div>

              {/* Caption Progress with Speech Correlation */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span>تقدم النص</span>
                  <span>ثقة الكلام: {Math.round(audioData.speechConfidence)}%</span>
                </div>
                <div className="relative w-full h-4 bg-gray-700 rounded">
                  {/* Caption progress */}
                  <div 
                    className="absolute top-0 left-0 h-full bg-blue-500 rounded transition-all"
                    style={{ 
                      width: `${Math.max(0, Math.min(100, 
                        ((currentTime + syncOffset - currentCaption.startTime) / 
                        (currentCaption.endTime - currentCaption.startTime)) * 100
                      ))}%` 
                    }}
                  />
                  {/* Speech confidence overlay */}
                  <div 
                    className="absolute top-0 left-0 h-full bg-red-500/50 rounded transition-all"
                    style={{ width: `${audioData.speechConfidence}%` }}
                  />
                </div>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>أزرق: تقدم النص</span>
                  <span>أحمر: ثقة الكلام</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Hidden video element for audio analysis */}
      {!isYouTubeVideo && (
        <video
          ref={videoRef}
          className="hidden"
          crossOrigin="anonymous"
          onTimeUpdate={() => {
            if (videoRef.current) {
              onTimeUpdate(videoRef.current.currentTime * 1000);
            }
          }}
        >
          <source src={`/api/videos/${project.id}/stream`} type="video/mp4" />
        </video>
      )}
    </div>
  );
}