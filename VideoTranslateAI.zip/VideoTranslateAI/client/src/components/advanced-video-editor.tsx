import { useState, useEffect, useRef } from "react";
import { VideoProject, Caption } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Play, Pause, SkipBack, SkipForward, Volume2, 
  Type, Palette, Move, Download, Scissors, 
  Plus, Trash2, Edit3, Languages, Sparkles,
  Upload, FileVideo, Youtube, Save, Eye,
  Settings, Sliders, Layers, Zap
} from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AdvancedVideoEditorProps {
  project: VideoProject;
}

interface CaptionSegment {
  id: number;
  text: string;
  startTime: number;
  endTime: number;
  language: string;
  translation?: string;
}

export function AdvancedVideoEditor({ project }: AdvancedVideoEditorProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(100);
  const [selectedCaption, setSelectedCaption] = useState<CaptionSegment | null>(null);
  const [newCaptionText, setNewCaptionText] = useState("");
  const [translationLanguage, setTranslationLanguage] = useState("ar");
  const [captionStyle, setCaptionStyle] = useState({
    fontSize: "medium",
    fontFamily: "Arial",
    textColor: "#ffffff",
    backgroundColor: "#000000",
    position: "bottom",
    alignment: "center",
    bold: false,
    italic: false,
    shadow: true,
    outline: false,
    glow: false
  });

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check if this is a YouTube video
  const isYouTubeVideo = project.originalPath?.includes('youtube.com') || project.originalPath?.includes('youtu.be');
  
  const getYouTubeVideoId = (url: string) => {
    try {
      const urlObj = new URL(url);
      if (urlObj.hostname.includes('youtube.com')) {
        return urlObj.searchParams.get('v') || '';
      } else if (urlObj.hostname.includes('youtu.be')) {
        return urlObj.pathname.slice(1);
      }
    } catch {
      return '';
    }
    return '';
  };

  const youtubeVideoId = isYouTubeVideo ? getYouTubeVideoId(project.originalPath) : '';

  // Fetch captions
  const { data: captions = [], refetch: refetchCaptions } = useQuery<CaptionSegment[]>({
    queryKey: ["/api/videos", project.id, "captions"],
    queryFn: async () => {
      const response = await fetch(`/api/videos/${project.id}/captions`, {
        credentials: "include",
      });
      if (!response.ok) return [];
      return response.json();
    },
  });

  // Generate captions using AI
  const generateCaptionsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/videos/${project.id}/generate-captions`, {});
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم إنشاء الترجمة",
        description: "تم إنشاء الترجمة باستخدام الذكاء الاصطناعي بنجاح",
      });
      refetchCaptions();
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطأ في إنشاء الترجمة",
        description: error.message,
      });
    },
  });

  // Translate captions
  const translateCaptionsMutation = useMutation({
    mutationFn: async (language: string) => {
      const response = await apiRequest("POST", `/api/videos/${project.id}/translate`, { language });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم الترجمة",
        description: "تم ترجمة النصوص بنجاح",
      });
      refetchCaptions();
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطأ في الترجمة",
        description: error.message,
      });
    },
  });

  // Add new caption
  const addCaptionMutation = useMutation({
    mutationFn: async (caption: { text: string; startTime: number; endTime: number }) => {
      const response = await apiRequest("POST", `/api/videos/${project.id}/captions`, caption);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم إضافة النص",
        description: "تم إضافة النص بنجاح",
      });
      setNewCaptionText("");
      refetchCaptions();
    },
  });

  // Update caption style
  const updateStyleMutation = useMutation({
    mutationFn: async (style: any) => {
      const response = await apiRequest("POST", `/api/videos/${project.id}/style`, style);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم تحديث التنسيق",
        description: "تم تحديث تنسيق النصوص بنجاح",
      });
    },
  });

  // Video controls
  const togglePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime * 1000);
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration * 1000);
    }
  };

  const seekTo = (time: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = time / 1000;
      setCurrentTime(time);
    }
  };

  const addCaptionAtCurrentTime = () => {
    if (newCaptionText.trim()) {
      addCaptionMutation.mutate({
        text: newCaptionText,
        startTime: currentTime,
        endTime: currentTime + 3000, // 3 seconds duration
      });
    }
  };

  // Find current caption
  const currentCaption = captions.find(
    caption => currentTime >= caption.startTime && currentTime <= caption.endTime
  );

  const formatTime = (ms: number) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="h-full flex flex-col glass-effect rounded-xl overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 via-blue-600 to-cyan-600 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">محرر الفيديو المتقدم</h2>
              <p className="text-blue-100 text-sm">{project.filename}</p>
            </div>
          </div>
          <div className="flex space-x-2">
            <Button 
              onClick={() => generateCaptionsMutation.mutate()}
              disabled={generateCaptionsMutation.isPending}
              className="bg-white/20 hover:bg-white/30 text-white"
            >
              <Zap className="w-4 h-4 mr-2" />
              إنشاء ترجمة AI
            </Button>
            <Button 
              onClick={() => updateStyleMutation.mutate(captionStyle)}
              disabled={updateStyleMutation.isPending}
              className="bg-white/20 hover:bg-white/30 text-white"
            >
              <Save className="w-4 h-4 mr-2" />
              حفظ التنسيق
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 flex">
        {/* Video Player Section */}
        <div className="flex-1 p-4">
          <div className="relative w-full h-[400px] bg-black rounded-lg overflow-hidden mb-4">
            {isYouTubeVideo && youtubeVideoId ? (
              <iframe
                width="100%"
                height="100%"
                src={`https://www.youtube.com/embed/${youtubeVideoId}?enablejsapi=1`}
                title="YouTube video player"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="w-full h-full"
              />
            ) : (
              <video
                ref={videoRef}
                className="w-full h-full object-contain"
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={handleLoadedMetadata}
                crossOrigin="anonymous"
              >
                <source src={`/api/videos/${project.id}/stream`} type="video/mp4" />
              </video>
            )}

            {/* Caption Overlay */}
            {currentCaption && (
              <div className={`absolute ${captionStyle.position === 'top' ? 'top-4' : captionStyle.position === 'middle' ? 'top-1/2 -translate-y-1/2' : 'bottom-4'} left-4 right-4`}>
                <div 
                  className={`px-4 py-2 rounded-lg ${captionStyle.alignment === 'left' ? 'text-left' : captionStyle.alignment === 'right' ? 'text-right' : 'text-center'}`}
                  style={{
                    backgroundColor: captionStyle.backgroundColor + '80',
                    backdropFilter: 'blur(10px)',
                  }}
                >
                  <p 
                    style={{
                      fontFamily: captionStyle.fontFamily,
                      fontSize: captionStyle.fontSize === 'small' ? '14px' : captionStyle.fontSize === 'medium' ? '18px' : captionStyle.fontSize === 'large' ? '24px' : '32px',
                      color: captionStyle.textColor,
                      fontWeight: captionStyle.bold ? 'bold' : 'normal',
                      fontStyle: captionStyle.italic ? 'italic' : 'normal',
                      textShadow: captionStyle.shadow ? '2px 2px 4px rgba(0,0,0,0.8)' : 'none',
                      WebkitTextStroke: captionStyle.outline ? '1px black' : 'none',
                      filter: captionStyle.glow ? 'drop-shadow(0 0 8px currentColor)' : 'none',
                    }}
                  >
                    {currentCaption.translation || currentCaption.text}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Video Controls */}
          <div className="glass-effect p-4 rounded-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-4">
                <Button onClick={() => seekTo(Math.max(0, currentTime - 10000))} variant="outline" size="sm">
                  <SkipBack className="w-4 h-4" />
                </Button>
                <Button onClick={togglePlayPause} size="sm">
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </Button>
                <Button onClick={() => seekTo(currentTime + 10000)} variant="outline" size="sm">
                  <SkipForward className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex items-center space-x-2">
                <Volume2 className="w-4 h-4" />
                <Slider
                  value={[volume]}
                  onValueChange={(value) => setVolume(value[0])}
                  max={100}
                  step={1}
                  className="w-20"
                />
                <span className="text-sm w-8">{volume}%</span>
              </div>
            </div>

            {/* Timeline */}
            <div className="space-y-2">
              <Slider
                value={[currentTime]}
                onValueChange={(value) => seekTo(value[0])}
                max={duration || 100000}
                step={100}
                className="w-full"
              />
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Editor Panel */}
        <div className="w-96 bg-gray-800/50 backdrop-blur-sm border-l border-gray-700">
          <Tabs defaultValue="captions" className="h-full">
            <TabsList className="grid w-full grid-cols-3 m-2">
              <TabsTrigger value="captions" className="text-xs">النصوص</TabsTrigger>
              <TabsTrigger value="style" className="text-xs">التنسيق</TabsTrigger>
              <TabsTrigger value="translate" className="text-xs">الترجمة</TabsTrigger>
            </TabsList>

            <TabsContent value="captions" className="p-4 space-y-4 h-full overflow-y-auto">
              {/* Add New Caption */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center">
                    <Plus className="w-4 h-4 mr-2" />
                    إضافة نص جديد
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Textarea
                    placeholder="اكتب النص هنا..."
                    value={newCaptionText}
                    onChange={(e) => setNewCaptionText(e.target.value)}
                    className="min-h-[80px]"
                  />
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                      الوقت الحالي: {formatTime(currentTime)}
                    </span>
                    <Button 
                      onClick={addCaptionAtCurrentTime}
                      disabled={!newCaptionText.trim() || addCaptionMutation.isPending}
                      size="sm"
                    >
                      إضافة
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Captions List */}
              <div className="space-y-2">
                <h3 className="text-sm font-semibold">النصوص الموجودة</h3>
                {captions.map((caption) => (
                  <Card 
                    key={caption.id} 
                    className={`cursor-pointer transition-all ${selectedCaption?.id === caption.id ? 'ring-2 ring-blue-500' : ''}`}
                    onClick={() => setSelectedCaption(caption)}
                  >
                    <CardContent className="p-3">
                      <div className="flex justify-between items-start mb-2">
                        <span className="text-xs text-muted-foreground">
                          {formatTime(caption.startTime)} - {formatTime(caption.endTime)}
                        </span>
                        <Badge variant="secondary" className="text-xs">
                          {caption.language}
                        </Badge>
                      </div>
                      <p className="text-sm">{caption.text}</p>
                      {caption.translation && (
                        <p className="text-sm text-blue-400 mt-1">{caption.translation}</p>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="style" className="p-4 space-y-4 h-full overflow-y-auto">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center">
                    <Palette className="w-4 h-4 mr-2" />
                    تنسيق النصوص
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Font Settings */}
                  <div className="space-y-2">
                    <Label className="text-sm">الخط</Label>
                    <Select value={captionStyle.fontFamily} onValueChange={(value) => setCaptionStyle(prev => ({ ...prev, fontFamily: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Arial">Arial</SelectItem>
                        <SelectItem value="Cairo">Cairo</SelectItem>
                        <SelectItem value="Roboto">Roboto</SelectItem>
                        <SelectItem value="Noto Sans Arabic">Noto Sans Arabic</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm">حجم الخط</Label>
                    <Select value={captionStyle.fontSize} onValueChange={(value) => setCaptionStyle(prev => ({ ...prev, fontSize: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="small">صغير</SelectItem>
                        <SelectItem value="medium">متوسط</SelectItem>
                        <SelectItem value="large">كبير</SelectItem>
                        <SelectItem value="xlarge">كبير جداً</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Colors */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label className="text-sm">لون النص</Label>
                      <Input
                        type="color"
                        value={captionStyle.textColor}
                        onChange={(e) => setCaptionStyle(prev => ({ ...prev, textColor: e.target.value }))}
                        className="h-10"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm">لون الخلفية</Label>
                      <Input
                        type="color"
                        value={captionStyle.backgroundColor}
                        onChange={(e) => setCaptionStyle(prev => ({ ...prev, backgroundColor: e.target.value }))}
                        className="h-10"
                      />
                    </div>
                  </div>

                  {/* Position */}
                  <div className="space-y-2">
                    <Label className="text-sm">الموضع</Label>
                    <Select value={captionStyle.position} onValueChange={(value) => setCaptionStyle(prev => ({ ...prev, position: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="top">أعلى</SelectItem>
                        <SelectItem value="middle">وسط</SelectItem>
                        <SelectItem value="bottom">أسفل</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm">المحاذاة</Label>
                    <Select value={captionStyle.alignment} onValueChange={(value) => setCaptionStyle(prev => ({ ...prev, alignment: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="left">يسار</SelectItem>
                        <SelectItem value="center">وسط</SelectItem>
                        <SelectItem value="right">يمين</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Style Options */}
                  <Separator />
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm">عريض</Label>
                      <Button
                        variant={captionStyle.bold ? "default" : "outline"}
                        size="sm"
                        onClick={() => setCaptionStyle(prev => ({ ...prev, bold: !prev.bold }))}
                      >
                        B
                      </Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <Label className="text-sm">مائل</Label>
                      <Button
                        variant={captionStyle.italic ? "default" : "outline"}
                        size="sm"
                        onClick={() => setCaptionStyle(prev => ({ ...prev, italic: !prev.italic }))}
                      >
                        I
                      </Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <Label className="text-sm">ظل</Label>
                      <Button
                        variant={captionStyle.shadow ? "default" : "outline"}
                        size="sm"
                        onClick={() => setCaptionStyle(prev => ({ ...prev, shadow: !prev.shadow }))}
                      >
                        S
                      </Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <Label className="text-sm">إطار</Label>
                      <Button
                        variant={captionStyle.outline ? "default" : "outline"}
                        size="sm"
                        onClick={() => setCaptionStyle(prev => ({ ...prev, outline: !prev.outline }))}
                      >
                        O
                      </Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <Label className="text-sm">توهج</Label>
                      <Button
                        variant={captionStyle.glow ? "default" : "outline"}
                        size="sm"
                        onClick={() => setCaptionStyle(prev => ({ ...prev, glow: !prev.glow }))}
                      >
                        G
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="translate" className="p-4 space-y-4 h-full overflow-y-auto">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center">
                    <Languages className="w-4 h-4 mr-2" />
                    ترجمة النصوص
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-sm">اللغة المستهدفة</Label>
                    <Select value={translationLanguage} onValueChange={setTranslationLanguage}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ar">العربية</SelectItem>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="fr">Français</SelectItem>
                        <SelectItem value="es">Español</SelectItem>
                        <SelectItem value="de">Deutsch</SelectItem>
                        <SelectItem value="it">Italiano</SelectItem>
                        <SelectItem value="pt">Português</SelectItem>
                        <SelectItem value="ru">Русский</SelectItem>
                        <SelectItem value="ja">日本語</SelectItem>
                        <SelectItem value="ko">한국어</SelectItem>
                        <SelectItem value="zh">中文</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button
                    onClick={() => translateCaptionsMutation.mutate(translationLanguage)}
                    disabled={translateCaptionsMutation.isPending}
                    className="w-full"
                  >
                    <Languages className="w-4 h-4 mr-2" />
                    {translateCaptionsMutation.isPending ? "جاري الترجمة..." : "ترجمة جميع النصوص"}
                  </Button>

                  <div className="text-center text-xs text-muted-foreground">
                    باستخدام Gemini AI للترجمة الدقيقة
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}