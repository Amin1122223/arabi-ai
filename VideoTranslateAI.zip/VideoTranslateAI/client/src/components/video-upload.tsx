import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { CloudUpload, FileVideo, Youtube, Link2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { VideoProject } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface VideoUploadProps {
  onProjectCreated: (project: VideoProject) => void;
}

export function VideoUpload({ onProjectCreated }: VideoUploadProps) {
  const [uploadProgress, setUploadProgress] = useState(0);
  const [youtubeUrl, setYoutubeUrl] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("video", file);

      const response = await fetch("/api/videos/upload", {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Upload failed");
      }

      return response.json();
    },
    onSuccess: (project: VideoProject) => {
      toast({
        title: "تم رفع الفيديو",
        description: "تم رفع الفيديو بنجاح.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      onProjectCreated(project);
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "فشل في الرفع",
        description: error.message,
      });
      setUploadProgress(0);
    },
  });

  const youtubeImportMutation = useMutation({
    mutationFn: async (url: string) => {
      const response = await apiRequest("POST", "/api/videos/import-youtube", { url });
      return response.json();
    },
    onSuccess: (project: VideoProject) => {
      toast({
        title: "تم استيراد الفيديو",
        description: "تم استيراد الفيديو من YouTube بنجاح.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      onProjectCreated(project);
      setYoutubeUrl("");
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "فشل في الاستيراد",
        description: error.message,
      });
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    // Validate file type
    const allowedTypes = ['video/mp4', 'video/avi', 'video/mov', 'video/quicktime', 'video/x-msvideo'];
    if (!allowedTypes.includes(file.type)) {
      toast({
        variant: "destructive",
        title: "نوع ملف غير مدعوم",
        description: "يرجى رفع ملف فيديو صالح (MP4, AVI, MOV).",
      });
      return;
    }

    // Validate file size (100MB limit)
    if (file.size > 100 * 1024 * 1024) {
      toast({
        variant: "destructive",
        title: "الملف كبير جداً",
        description: "يرجى رفع ملف فيديو أصغر من 100 ميجابايت.",
      });
      return;
    }

    setUploadProgress(25);
    uploadMutation.mutate(file);
  }, [uploadMutation, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'video/*': ['.mp4', '.avi', '.mov', '.mkv', '.webm']
    },
    multiple: false,
  });

  const handleYoutubeImport = () => {
    if (!youtubeUrl.trim()) {
      toast({
        variant: "destructive",
        title: "رابط مطلوب",
        description: "يرجى إدخال رابط YouTube صالح.",
      });
      return;
    }
    youtubeImportMutation.mutate(youtubeUrl);
  };

  const isProcessing = uploadMutation.isPending || youtubeImportMutation.isPending;

  return (
    <div className="h-full flex flex-col relative">
      {isProcessing ? (
        <div className="flex-1 flex items-center justify-center animate-fade-in">
          <div className="w-full max-w-lg glass-effect p-8 rounded-2xl neon-glow-blue">
            <div className="text-center mb-8">
              <div className="relative mx-auto mb-6 w-20 h-20">
                <div className="absolute inset-0 animate-spin">
                  <div className="h-full w-full rounded-full border-4 border-transparent border-t-blue-500 border-r-purple-500"></div>
                </div>
                <div className="absolute inset-2 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
                  {youtubeImportMutation.isPending ? (
                    <Youtube className="h-8 w-8 text-white" />
                  ) : (
                    <CloudUpload className="h-8 w-8 text-white" />
                  )}
                </div>
              </div>
              <h3 className="text-2xl font-bold gradient-text mb-3">
                {youtubeImportMutation.isPending ? "جاري استيراد الفيديو" : "جاري رفع الفيديو"}
              </h3>
              <p className="text-muted-foreground">
                {youtubeImportMutation.isPending 
                  ? "يرجى الانتظار بينما نستورد الفيديو من YouTube..."
                  : "يرجى الانتظار بينما نقوم بمعالجة الفيديو الخاص بك..."
                }
              </p>
            </div>
            {uploadMutation.isPending && (
              <div className="space-y-4">
                <Progress value={uploadProgress} className="w-full h-2" />
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>{uploadProgress}% مكتمل</span>
                  <span>يتم الرفع...</span>
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col p-8">
          {/* CapCut-Style Header */}
          <div className="text-center mb-8 animate-slide-in">
            <div className="relative mx-auto w-24 h-24 mb-6">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 rounded-3xl opacity-20 animate-pulse"></div>
              <div className="relative bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 rounded-3xl p-4 neon-glow-blue">
                <Sparkles className="w-full h-full text-white" />
              </div>
            </div>
            <h1 className="text-4xl font-bold gradient-text mb-4">استوديو التحرير المتقدم</h1>
            <p className="text-xl text-muted-foreground">اختر طريقة إضافة الفيديو للبدء في التحرير والترجمة</p>
          </div>

          {/* CapCut-Style Tabs */}
          <Tabs defaultValue="upload" className="w-full max-w-4xl mx-auto">
            <TabsList className="grid w-full grid-cols-2 mb-8 glass-effect">
              <TabsTrigger value="upload" className="flex items-center space-x-2 font-medium">
                <CloudUpload className="w-5 h-5" />
                <span>رفع ملف</span>
              </TabsTrigger>
              <TabsTrigger value="youtube" className="flex items-center space-x-2 font-medium">
                <Youtube className="w-5 h-5" />
                <span>استيراد من YouTube</span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="upload" className="animate-fade-in">
              <div className="gradient-border mb-8">
                <div 
                  {...getRootProps()} 
                  className={`gradient-border-content p-16 text-center cursor-pointer transition-all duration-300 relative overflow-hidden ${
                    isDragActive ? 'scale-105 neon-glow-purple' : 'hover:scale-102'
                  }`}
                >
                  <input {...getInputProps()} />
                  
                  {/* Content */}
                  <div className="relative z-10">
                    <div className="animate-float mb-8">
                      <div className="relative mx-auto w-32 h-32">
                        <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-purple-500 rounded-3xl opacity-20 animate-pulse"></div>
                        <div className="relative bg-gradient-to-br from-blue-500 to-purple-500 rounded-3xl p-6 neon-glow-blue">
                          <CloudUpload className="w-full h-full text-white" />
                        </div>
                      </div>
                    </div>
                    
                    <h3 className="text-4xl font-bold gradient-text mb-6">
                      {isDragActive ? "أفلت الفيديو هنا" : "ارفع الفيديو الخاص بك"}
                    </h3>
                    
                    <p className="text-xl text-muted-foreground mb-8 max-w-lg mx-auto">
                      {isDragActive 
                        ? "أفلت ملف الفيديو هنا الآن..." 
                        : "اسحب وأفلت ملف الفيديو هنا أو انقر للتصفح"
                      }
                    </p>
                    
                    {/* Supported Formats */}
                    <div className="flex justify-center space-x-8 text-base text-muted-foreground mb-10">
                      <span className="flex items-center glass-effect px-6 py-3 rounded-xl">
                        <FileVideo className="mr-3 h-6 w-6 text-blue-400" />
                        MP4
                      </span>
                      <span className="flex items-center glass-effect px-6 py-3 rounded-xl">
                        <FileVideo className="mr-3 h-6 w-6 text-purple-400" />
                        AVI
                      </span>
                      <span className="flex items-center glass-effect px-6 py-3 rounded-xl">
                        <FileVideo className="mr-3 h-6 w-6 text-pink-400" />
                        MOV
                      </span>
                    </div>
                    
                    <Button className="bg-gradient-to-r from-purple-500 via-pink-500 to-blue-500 hover:from-purple-600 hover:via-pink-600 hover:to-blue-600 font-bold text-xl px-12 py-4 neon-glow-purple">
                      <CloudUpload className="mr-3 h-6 w-6" />
                      اختر ملف الفيديو
                    </Button>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="youtube" className="animate-fade-in">
              <div className="glass-effect p-12 rounded-2xl neon-glow-cyan">
                <div className="text-center mb-8">
                  <div className="relative mx-auto w-24 h-24 mb-6">
                    <div className="absolute inset-0 bg-gradient-to-br from-red-500 to-pink-500 rounded-2xl opacity-20 animate-pulse"></div>
                    <div className="relative bg-gradient-to-br from-red-500 to-pink-500 rounded-2xl p-4 neon-glow-pink">
                      <Youtube className="w-full h-full text-white" />
                    </div>
                  </div>
                  <h3 className="text-3xl font-bold gradient-text mb-4">استيراد من YouTube</h3>
                  <p className="text-lg text-muted-foreground mb-8">أدخل رابط الفيديو من YouTube لبدء التحرير والترجمة</p>
                </div>
                
                <div className="space-y-6 max-w-xl mx-auto">
                  <div className="relative">
                    <Link2 className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                    <Input
                      type="url"
                      placeholder="https://www.youtube.com/watch?v=..."
                      value={youtubeUrl}
                      onChange={(e) => setYoutubeUrl(e.target.value)}
                      className="pl-12 py-4 text-lg glass-effect border-0 focus:ring-2 focus:ring-blue-500"
                      dir="ltr"
                    />
                  </div>
                  
                  <Button 
                    onClick={handleYoutubeImport}
                    disabled={!youtubeUrl.trim()}
                    className="w-full bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 font-bold text-xl py-4 neon-glow-pink"
                  >
                    <Youtube className="mr-3 h-6 w-6" />
                    استيراد الفيديو
                  </Button>
                </div>
                
                <div className="mt-8 text-center">
                  <p className="text-sm text-muted-foreground">
                    ✓ دعم جودة عالية &nbsp;&nbsp;&nbsp; ✓ استخراج تلقائي للصوت &nbsp;&nbsp;&nbsp; ✓ حفظ معلومات الفيديو
                  </p>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {/* Enhanced Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-12 animate-fade-in">
            <div className="glass-effect p-6 rounded-xl text-center hover:neon-glow-blue transition-all">
              <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl mx-auto mb-4 flex items-center justify-center">
                <span className="text-3xl">🤖</span>
              </div>
              <h4 className="font-bold text-lg mb-2">ذكاء اصطناعي متقدم</h4>
              <p className="text-sm text-muted-foreground">Gemini AI للترجمة الدقيقة</p>
            </div>
            
            <div className="glass-effect p-6 rounded-xl text-center hover:neon-glow-purple transition-all">
              <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl mx-auto mb-4 flex items-center justify-center">
                <span className="text-3xl">⚡</span>
              </div>
              <h4 className="font-bold text-lg mb-2">معالجة سريعة</h4>
              <p className="text-sm text-muted-foreground">ترجمة فورية وتأثيرات مبهرة</p>
            </div>
            
            <div className="glass-effect p-6 rounded-xl text-center hover:neon-glow-green transition-all">
              <div className="w-14 h-14 bg-gradient-to-br from-green-500 to-teal-500 rounded-xl mx-auto mb-4 flex items-center justify-center">
                <span className="text-3xl">🎨</span>
              </div>
              <h4 className="font-bold text-lg mb-2">تصميم احترافي</h4>
              <p className="text-sm text-muted-foreground">أدوات تخصيص متقدمة</p>
            </div>
            
            <div className="glass-effect p-6 rounded-xl text-center hover:neon-glow-pink transition-all">
              <div className="w-14 h-14 bg-gradient-to-br from-pink-500 to-red-500 rounded-xl mx-auto mb-4 flex items-center justify-center">
                <span className="text-3xl">📱</span>
              </div>
              <h4 className="font-bold text-lg mb-2">تصدير متعدد</h4>
              <p className="text-sm text-muted-foreground">تصدير بجودات مختلفة</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
