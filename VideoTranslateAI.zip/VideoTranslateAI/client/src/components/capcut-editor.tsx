import { useState, useEffect, useRef } from "react";
import { VideoProject, Caption } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { AdvancedAudioSync } from "@/components/advanced-audio-sync";
import { 
  Play, Pause, SkipBack, SkipForward, Volume2, VolumeX,
  Type, Palette, Move, Download, Scissors, Wand2,
  Plus, Trash2, Edit3, Languages, Sparkles, Zap,
  Upload, FileVideo, Youtube, Save, Eye, Copy,
  Settings, Sliders, Layers, MousePointer,
  RotateCcw, RotateCw, Crop, Filter, Contrast,
  Music, Mic, Split, Merge
} from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface CapCutEditorProps {
  project: VideoProject;
}

interface CaptionSegment {
  id: number;
  text: string;
  startTime: number;
  endTime: number;
  language: string;
  translation?: string;
}

interface VideoEffect {
  id: string;
  name: string;
  type: 'filter' | 'transition' | 'text' | 'sticker';
  thumbnail: string;
}

export function CapCutEditor({ project }: CapCutEditorProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(30000); // 30 seconds default
  const [volume, setVolume] = useState(100);
  const [selectedCaption, setSelectedCaption] = useState<CaptionSegment | null>(null);
  const [newCaptionText, setNewCaptionText] = useState("");
  const [translationLanguage, setTranslationLanguage] = useState("ar");
  const [zoom, setZoom] = useState(100);
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [saturation, setSaturation] = useState(100);
  const [rotation, setRotation] = useState(0);
  const [activeTab, setActiveTab] = useState("captions");
  
  const [captionStyle, setCaptionStyle] = useState({
    fontSize: "medium",
    fontFamily: "Cairo",
    textColor: "#ffffff",
    backgroundColor: "#000000",
    position: "bottom",
    alignment: "center",
    bold: false,
    italic: false,
    shadow: true,
    outline: false,
    glow: false,
    opacity: 90,
    borderRadius: 8,
    padding: 12
  });

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check if this is a YouTube video
  const isYouTubeVideo = project.originalPath?.includes('youtube.com') || project.originalPath?.includes('youtu.be');
  
  const getYouTubeVideoId = (url: string) => {
    try {
      if (url.includes('youtu.be/')) {
        return url.split('youtu.be/')[1].split('?')[0].split('&')[0];
      } else if (url.includes('youtube.com/watch?v=')) {
        return url.split('v=')[1].split('&')[0];
      } else if (url.includes('youtube.com/embed/')) {
        return url.split('embed/')[1].split('?')[0];
      }
    } catch {
      return '';
    }
    return '';
  };

  const youtubeVideoId = isYouTubeVideo ? getYouTubeVideoId(project.originalPath) : '';

  // Fetch captions
  const { data: captions = [], refetch: refetchCaptions } = useQuery<CaptionSegment[]>({
    queryKey: ["/api/videos", project.id, "captions"],
    queryFn: async () => {
      const response = await fetch(`/api/videos/${project.id}/captions`, {
        credentials: "include",
      });
      if (!response.ok) return [];
      return response.json();
    },
  });

  // Generate captions using AI
  const generateCaptionsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/videos/${project.id}/generate-captions`, {});
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم إنشاء الترجمة",
        description: "تم إنشاء الترجمة باستخدام الذكاء الاصطناعي بنجاح",
      });
      refetchCaptions();
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطأ في إنشاء الترجمة",
        description: error.message.includes('API key') ? 
          "يرجى إدخال مفتاح Gemini API في إعدادات البيئة" : 
          error.message,
      });
    },
  });

  // Translate captions
  const translateCaptionsMutation = useMutation({
    mutationFn: async (language: string) => {
      const response = await apiRequest("POST", `/api/videos/${project.id}/translate`, { language });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم الترجمة",
        description: "تم ترجمة النصوص بنجاح",
      });
      refetchCaptions();
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطأ في الترجمة",
        description: error.message.includes('API key') ? 
          "يرجى إدخال مفتاح Gemini API في إعدادات البيئة" : 
          error.message,
      });
    },
  });

  // Add new caption
  const addCaptionMutation = useMutation({
    mutationFn: async (caption: { text: string; startTime: number; endTime: number }) => {
      const response = await apiRequest("POST", `/api/videos/${project.id}/captions`, caption);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم إضافة النص",
        description: "تم إضافة النص بنجاح",
      });
      setNewCaptionText("");
      refetchCaptions();
    },
  });

  // Update caption style
  const updateStyleMutation = useMutation({
    mutationFn: async (style: any) => {
      const response = await apiRequest("POST", `/api/videos/${project.id}/style`, style);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم تحديث التنسيق",
        description: "تم تحديث تنسيق النصوص بنجاح",
      });
    },
  });

  // Video controls
  const togglePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime * 1000);
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration * 1000);
    }
  };

  const seekTo = (time: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = time / 1000;
      setCurrentTime(time);
    }
  };

  const addCaptionAtCurrentTime = () => {
    if (newCaptionText.trim()) {
      addCaptionMutation.mutate({
        text: newCaptionText,
        startTime: currentTime,
        endTime: currentTime + 3000,
      });
    }
  };

  // Find current caption
  const currentCaption = captions.find(
    caption => currentTime >= caption.startTime && currentTime <= caption.endTime
  );

  const formatTime = (ms: number) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  // Effects and filters
  const videoFilters = [
    { id: 'normal', name: 'عادي', filter: 'none' },
    { id: 'vintage', name: 'كلاسيكي', filter: 'sepia(0.5) contrast(1.2)' },
    { id: 'vibrant', name: 'نابض بالحياة', filter: 'saturate(1.5) contrast(1.1)' },
    { id: 'cool', name: 'بارد', filter: 'hue-rotate(180deg) saturate(1.2)' },
    { id: 'warm', name: 'دافئ', filter: 'hue-rotate(-30deg) saturate(1.3)' },
    { id: 'dramatic', name: 'دراماتيكي', filter: 'contrast(1.5) brightness(0.9)' },
  ];

  const transitions = [
    { id: 'fade', name: 'تلاشي', duration: 500 },
    { id: 'slide', name: 'انزلاق', duration: 750 },
    { id: 'zoom', name: 'تكبير', duration: 600 },
    { id: 'flip', name: 'قلب', duration: 800 },
  ];

  return (
    <div className="h-full flex flex-col glass-effect rounded-xl overflow-hidden">
      {/* CapCut-Style Header */}
      <div className="bg-gradient-to-r from-purple-600 via-blue-600 to-cyan-600 p-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">CapCut Pro Editor</h2>
              <p className="text-blue-100 text-xs">{project.filename}</p>
            </div>
          </div>
          <div className="flex space-x-2">
            <Button 
              onClick={() => generateCaptionsMutation.mutate()}
              disabled={generateCaptionsMutation.isPending}
              size="sm"
              className="bg-white/20 hover:bg-white/30 text-white text-xs"
            >
              <Zap className="w-3 h-3 mr-1" />
              AI ترجمة
            </Button>
            <Button 
              onClick={() => updateStyleMutation.mutate(captionStyle)}
              disabled={updateStyleMutation.isPending}
              size="sm"
              className="bg-white/20 hover:bg-white/30 text-white text-xs"
            >
              <Save className="w-3 h-3 mr-1" />
              حفظ
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 flex">
        {/* Main Video Area */}
        <div className="flex-1 flex flex-col">
          {/* Video Player */}
          <div className="flex-1 p-4">
            <div className="relative w-full h-[400px] bg-black rounded-lg overflow-hidden mb-4">
              {isYouTubeVideo && youtubeVideoId ? (
                <iframe
                  width="100%"
                  height="100%"
                  src={`https://www.youtube.com/embed/${youtubeVideoId}?enablejsapi=1&controls=0`}
                  title="YouTube video player"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="w-full h-full"
                  style={{
                    filter: `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`,
                    transform: `rotate(${rotation}deg) scale(${zoom / 100})`
                  }}
                />
              ) : (
                <video
                  ref={videoRef}
                  className="w-full h-full object-contain"
                  onTimeUpdate={handleTimeUpdate}
                  onLoadedMetadata={handleLoadedMetadata}
                  crossOrigin="anonymous"
                  style={{
                    filter: `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`,
                    transform: `rotate(${rotation}deg) scale(${zoom / 100})`
                  }}
                >
                  <source src={`/api/videos/${project.id}/stream`} type="video/mp4" />
                </video>
              )}

              {/* Caption Overlay with CapCut Style */}
              {currentCaption && (
                <div className={`absolute ${captionStyle.position === 'top' ? 'top-4' : captionStyle.position === 'middle' ? 'top-1/2 -translate-y-1/2' : 'bottom-4'} left-4 right-4`}>
                  <div 
                    className={`px-${captionStyle.padding / 4} py-2 rounded-lg ${captionStyle.alignment === 'left' ? 'text-left' : captionStyle.alignment === 'right' ? 'text-right' : 'text-center'}`}
                    style={{
                      backgroundColor: captionStyle.backgroundColor + Math.round(captionStyle.opacity * 2.55).toString(16).padStart(2, '0'),
                      backdropFilter: 'blur(10px)',
                      borderRadius: `${captionStyle.borderRadius}px`,
                    }}
                  >
                    <p 
                      style={{
                        fontFamily: captionStyle.fontFamily,
                        fontSize: captionStyle.fontSize === 'small' ? '14px' : captionStyle.fontSize === 'medium' ? '18px' : captionStyle.fontSize === 'large' ? '24px' : '32px',
                        color: captionStyle.textColor,
                        fontWeight: captionStyle.bold ? 'bold' : 'normal',
                        fontStyle: captionStyle.italic ? 'italic' : 'normal',
                        textShadow: captionStyle.shadow ? '2px 2px 4px rgba(0,0,0,0.8)' : 'none',
                        WebkitTextStroke: captionStyle.outline ? '1px black' : 'none',
                        filter: captionStyle.glow ? 'drop-shadow(0 0 8px currentColor)' : 'none',
                      }}
                    >
                      {currentCaption.translation || currentCaption.text}
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Video Controls - CapCut Style */}
            <div className="glass-effect p-4 rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <Button onClick={() => seekTo(Math.max(0, currentTime - 10000))} variant="outline" size="sm">
                    <SkipBack className="w-4 h-4" />
                  </Button>
                  <Button onClick={togglePlayPause} size="sm" className="bg-blue-600 hover:bg-blue-700">
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </Button>
                  <Button onClick={() => seekTo(currentTime + 10000)} variant="outline" size="sm">
                    <SkipForward className="w-4 h-4" />
                  </Button>
                  <Button onClick={() => setVolume(volume === 0 ? 100 : 0)} variant="outline" size="sm">
                    {volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </Button>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs">الصوت</span>
                    <Slider
                      value={[volume]}
                      onValueChange={(value) => setVolume(value[0])}
                      max={100}
                      step={1}
                      className="w-20"
                    />
                    <span className="text-xs w-8">{volume}%</span>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <span className="text-xs">التكبير</span>
                    <Slider
                      value={[zoom]}
                      onValueChange={(value) => setZoom(value[0])}
                      min={50}
                      max={200}
                      step={5}
                      className="w-20"
                    />
                    <span className="text-xs w-12">{zoom}%</span>
                  </div>
                </div>
              </div>

              {/* Timeline */}
              <div className="space-y-2">
                <div className="relative">
                  <Slider
                    value={[currentTime]}
                    onValueChange={(value) => seekTo(value[0])}
                    max={duration || 100000}
                    step={100}
                    className="w-full"
                  />
                  {/* Caption markers on timeline */}
                  {captions.map((caption) => (
                    <div
                      key={caption.id}
                      className="absolute top-0 h-full bg-blue-500/30 rounded"
                      style={{
                        left: `${(caption.startTime / duration) * 100}%`,
                        width: `${((caption.endTime - caption.startTime) / duration) * 100}%`,
                      }}
                    />
                  ))}
                </div>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>{formatTime(currentTime)}</span>
                  <span>{formatTime(duration)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* CapCut-Style Right Panel */}
        <div className="w-80 bg-gray-900/50 backdrop-blur-sm border-l border-gray-700">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
            <TabsList className="grid w-full grid-cols-5 m-2">
              <TabsTrigger value="captions" className="text-xs">نصوص</TabsTrigger>
              <TabsTrigger value="sync" className="text-xs">مزامنة</TabsTrigger>
              <TabsTrigger value="effects" className="text-xs">تأثيرات</TabsTrigger>
              <TabsTrigger value="audio" className="text-xs">صوت</TabsTrigger>
              <TabsTrigger value="export" className="text-xs">تصدير</TabsTrigger>
            </TabsList>

            <TabsContent value="captions" className="p-4 space-y-4 h-full overflow-y-auto">
              {/* Add New Caption */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center">
                    <Plus className="w-4 h-4 mr-2" />
                    إضافة نص جديد
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Textarea
                    placeholder="اكتب النص هنا..."
                    value={newCaptionText}
                    onChange={(e) => setNewCaptionText(e.target.value)}
                    className="min-h-[60px] text-sm"
                  />
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      {formatTime(currentTime)}
                    </span>
                    <Button 
                      onClick={addCaptionAtCurrentTime}
                      disabled={!newCaptionText.trim() || addCaptionMutation.isPending}
                      size="sm"
                    >
                      إضافة
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Translation */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center">
                    <Languages className="w-4 h-4 mr-2" />
                    الترجمة الذكية
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Select value={translationLanguage} onValueChange={setTranslationLanguage}>
                    <SelectTrigger className="text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ar">العربية</SelectItem>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="fr">Français</SelectItem>
                      <SelectItem value="es">Español</SelectItem>
                      <SelectItem value="de">Deutsch</SelectItem>
                      <SelectItem value="zh">中文</SelectItem>
                      <SelectItem value="ja">日本語</SelectItem>
                      <SelectItem value="ko">한국어</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Button
                    onClick={() => translateCaptionsMutation.mutate(translationLanguage)}
                    disabled={translateCaptionsMutation.isPending}
                    className="w-full"
                    size="sm"
                  >
                    <Languages className="w-3 h-3 mr-1" />
                    {translateCaptionsMutation.isPending ? "جاري الترجمة..." : "ترجمة النصوص"}
                  </Button>
                </CardContent>
              </Card>

              {/* Caption Style */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center">
                    <Palette className="w-4 h-4 mr-2" />
                    تنسيق النصوص
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <Label className="text-xs">الخط</Label>
                      <Select 
                        value={captionStyle.fontFamily} 
                        onValueChange={(value) => setCaptionStyle(prev => ({ ...prev, fontFamily: value }))}
                      >
                        <SelectTrigger className="text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Cairo">Cairo</SelectItem>
                          <SelectItem value="Arial">Arial</SelectItem>
                          <SelectItem value="Roboto">Roboto</SelectItem>
                          <SelectItem value="Noto Sans Arabic">Noto Sans Arabic</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-1">
                      <Label className="text-xs">الحجم</Label>
                      <Select 
                        value={captionStyle.fontSize} 
                        onValueChange={(value) => setCaptionStyle(prev => ({ ...prev, fontSize: value }))}
                      >
                        <SelectTrigger className="text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="small">صغير</SelectItem>
                          <SelectItem value="medium">متوسط</SelectItem>
                          <SelectItem value="large">كبير</SelectItem>
                          <SelectItem value="xlarge">كبير جداً</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <Label className="text-xs">لون النص</Label>
                      <Input
                        type="color"
                        value={captionStyle.textColor}
                        onChange={(e) => setCaptionStyle(prev => ({ ...prev, textColor: e.target.value }))}
                        className="h-8"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">لون الخلفية</Label>
                      <Input
                        type="color"
                        value={captionStyle.backgroundColor}
                        onChange={(e) => setCaptionStyle(prev => ({ ...prev, backgroundColor: e.target.value }))}
                        className="h-8"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs">الشفافية ({captionStyle.opacity}%)</Label>
                    <Slider
                      value={[captionStyle.opacity]}
                      onValueChange={(value) => setCaptionStyle(prev => ({ ...prev, opacity: value[0] }))}
                      max={100}
                      step={5}
                      className="w-full"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={captionStyle.bold}
                        onCheckedChange={(checked) => setCaptionStyle(prev => ({ ...prev, bold: checked }))}
                      />
                      <Label className="text-xs">عريض</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={captionStyle.italic}
                        onCheckedChange={(checked) => setCaptionStyle(prev => ({ ...prev, italic: checked }))}
                      />
                      <Label className="text-xs">مائل</Label>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div className="flex items-center space-x-1">
                      <Switch
                        checked={captionStyle.shadow}
                        onCheckedChange={(checked) => setCaptionStyle(prev => ({ ...prev, shadow: checked }))}
                      />
                      <Label className="text-xs">ظل</Label>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Switch
                        checked={captionStyle.outline}
                        onCheckedChange={(checked) => setCaptionStyle(prev => ({ ...prev, outline: checked }))}
                      />
                      <Label className="text-xs">إطار</Label>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Switch
                        checked={captionStyle.glow}
                        onCheckedChange={(checked) => setCaptionStyle(prev => ({ ...prev, glow: checked }))}
                      />
                      <Label className="text-xs">توهج</Label>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Captions List */}
              <div className="space-y-2">
                <h3 className="text-sm font-semibold">النصوص الموجودة</h3>
                {captions.map((caption) => (
                  <Card 
                    key={caption.id} 
                    className={`cursor-pointer transition-all text-sm ${selectedCaption?.id === caption.id ? 'ring-2 ring-blue-500' : ''}`}
                    onClick={() => setSelectedCaption(caption)}
                  >
                    <CardContent className="p-3">
                      <div className="flex justify-between items-start mb-2">
                        <span className="text-xs text-muted-foreground">
                          {formatTime(caption.startTime)} - {formatTime(caption.endTime)}
                        </span>
                        <Badge variant="secondary" className="text-xs">
                          {caption.language}
                        </Badge>
                      </div>
                      <p className="text-xs">{caption.text}</p>
                      {caption.translation && (
                        <p className="text-xs text-blue-400 mt-1">{caption.translation}</p>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="sync" className="p-4 space-y-4 h-full overflow-y-auto">
              <AdvancedAudioSync
                project={project}
                captions={captions}
                currentTime={currentTime}
                isPlaying={isPlaying}
                onTimeUpdate={setCurrentTime}
              />
            </TabsContent>

            <TabsContent value="effects" className="p-4 space-y-4 h-full overflow-y-auto">
              {/* Video Filters */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center">
                    <Filter className="w-4 h-4 mr-2" />
                    فلاتر الفيديو
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-2">
                    {videoFilters.map((filter) => (
                      <Button
                        key={filter.id}
                        variant="outline"
                        size="sm"
                        className="h-16 text-xs"
                        onClick={() => {
                          // Apply filter logic here
                          toast({
                            title: "تم تطبيق الفلتر",
                            description: `تم تطبيق فلتر ${filter.name}`,
                          });
                        }}
                      >
                        {filter.name}
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Video Adjustments */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center">
                    <Sliders className="w-4 h-4 mr-2" />
                    تعديلات الفيديو
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-xs">السطوع</Label>
                      <span className="text-xs">{brightness}%</span>
                    </div>
                    <Slider
                      value={[brightness]}
                      onValueChange={(value) => setBrightness(value[0])}
                      min={50}
                      max={150}
                      step={5}
                      className="w-full"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-xs">التباين</Label>
                      <span className="text-xs">{contrast}%</span>
                    </div>
                    <Slider
                      value={[contrast]}
                      onValueChange={(value) => setContrast(value[0])}
                      min={50}
                      max={150}
                      step={5}
                      className="w-full"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-xs">التشبع</Label>
                      <span className="text-xs">{saturation}%</span>
                    </div>
                    <Slider
                      value={[saturation]}
                      onValueChange={(value) => setSaturation(value[0])}
                      min={50}
                      max={150}
                      step={5}
                      className="w-full"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-xs">الدوران</Label>
                      <span className="text-xs">{rotation}°</span>
                    </div>
                    <Slider
                      value={[rotation]}
                      onValueChange={(value) => setRotation(value[0])}
                      min={-180}
                      max={180}
                      step={15}
                      className="w-full"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      onClick={() => setRotation(rotation - 90)}
                      variant="outline"
                      size="sm"
                    >
                      <RotateCcw className="w-3 h-3 mr-1" />
                      يسار
                    </Button>
                    <Button
                      onClick={() => setRotation(rotation + 90)}
                      variant="outline"
                      size="sm"
                    >
                      <RotateCw className="w-3 h-3 mr-1" />
                      يمين
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="audio" className="p-4 space-y-4 h-full overflow-y-auto">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center">
                    <Music className="w-4 h-4 mr-2" />
                    إعدادات الصوت
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <Label className="text-xs">مستوى الصوت الرئيسي</Label>
                    <Slider
                      value={[volume]}
                      onValueChange={(value) => setVolume(value[0])}
                      max={100}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  <Button className="w-full" size="sm" variant="outline">
                    <Mic className="w-3 h-3 mr-1" />
                    إضافة تعليق صوتي
                  </Button>

                  <Button className="w-full" size="sm" variant="outline">
                    <Music className="w-3 h-3 mr-1" />
                    إضافة موسيقى خلفية
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="export" className="p-4 space-y-4 h-full overflow-y-auto">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center">
                    <Download className="w-4 h-4 mr-2" />
                    تصدير المشروع
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <Label className="text-xs">جودة التصدير</Label>
                    <Select defaultValue="1080p">
                      <SelectTrigger className="text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="4k">4K (3840x2160)</SelectItem>
                        <SelectItem value="1080p">Full HD (1920x1080)</SelectItem>
                        <SelectItem value="720p">HD (1280x720)</SelectItem>
                        <SelectItem value="480p">SD (854x480)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs">تنسيق الملف</Label>
                    <Select defaultValue="mp4">
                      <SelectTrigger className="text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mp4">MP4</SelectItem>
                        <SelectItem value="mov">MOV</SelectItem>
                        <SelectItem value="avi">AVI</SelectItem>
                        <SelectItem value="webm">WebM</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600">
                    <Download className="w-3 h-3 mr-1" />
                    تصدير الفيديو
                  </Button>

                  <div className="text-xs text-center text-muted-foreground">
                    سيتم تصدير الفيديو مع جميع النصوص والتأثيرات
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}