import { useState } from "react";
import { VideoProject, CaptionStyle } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  Languages, 
  Type, 
  Palette,
  Bold,
  Italic,
  Eye,
  Sparkles,
  Move,
  AlignLeft,
  AlignCenter,
  AlignRight
} from "lucide-react";

interface ControlsPanelProps {
  selectedProject: VideoProject | null;
}

const LANGUAGES = [
  { value: "auto", label: "تلقائي" },
  { value: "en", label: "English" },
  { value: "ar", label: "العربية" },
  { value: "es", label: "Español" },
  { value: "fr", label: "Français" },
  { value: "de", label: "Deutsch" },
  { value: "zh", label: "中文" },
  { value: "ja", label: "日本語" },
];

const FONT_FAMILIES = [
  { value: "Inter", label: "Inter" },
  { value: "Roboto", label: "Roboto" },
  { value: "Open Sans", label: "Open Sans" },
  { value: "Montserrat", label: "Montserrat" },
  { value: "Arial", label: "Arial" },
];

const FONT_SIZES = [
  { value: "small", label: "صغير" },
  { value: "medium", label: "متوسط" },
  { value: "large", label: "كبير" },
  { value: "x-large", label: "كبير جداً" },
];

const TEXT_COLORS = [
  "#ffffff", "#ffff00", "#ff0000", "#00ff00", "#0000ff", "#ff00ff", "#00ffff", "#ffa500"
];

const EMOJIS = [
  "😊", "👍", "❤️", "🎉", "💡", "🚀", "📊", "⭐", "🔥", "💎", "🎯", "✨"
];

export function ControlsPanel({ selectedProject }: ControlsPanelProps) {
  const [sourceLanguage, setSourceLanguage] = useState("auto");
  const [targetLanguage, setTargetLanguage] = useState("ar");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: style } = useQuery<CaptionStyle>({
    queryKey: ["/api/videos", selectedProject?.id, "style"],
    enabled: !!selectedProject,
  });

  const generateCaptionsMutation = useMutation({
    mutationFn: async ({ projectId, sourceLanguage, targetLanguage }: { 
      projectId: number; 
      sourceLanguage: string; 
      targetLanguage: string; 
    }) => {
      const response = await apiRequest("POST", `/api/videos/${projectId}/generate-captions`, {
        sourceLanguage,
        targetLanguage,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم توليد الترجمات",
        description: "تم توليد ترجمات الفيديو بنجاح.",
      });
      queryClient.invalidateQueries({ 
        queryKey: ["/api/videos", selectedProject?.id, "captions"] 
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "فشل في التوليد",
        description: error.message,
      });
    },
  });

  const updateStyleMutation = useMutation({
    mutationFn: async (styleData: any) => {
      const response = await apiRequest("PUT", `/api/videos/${selectedProject?.id}/style`, styleData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/videos", selectedProject?.id, "style"] 
      });
    },
  });

  const handleGenerateCaptions = () => {
    if (!selectedProject) return;
    
    generateCaptionsMutation.mutate({
      projectId: selectedProject.id,
      sourceLanguage,
      targetLanguage,
    });
  };

  const handleStyleUpdate = (updates: any) => {
    if (!selectedProject) return;
    updateStyleMutation.mutate(updates);
  };

  if (!selectedProject) {
    return (
      <div className="w-96 glass-effect border-l border-border overflow-y-auto animate-slide-in">
        <div className="p-8 text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-500 rounded-2xl mx-auto mb-6 flex items-center justify-center neon-glow-blue animate-pulse-glow">
            <span className="text-3xl">📹</span>
          </div>
          <h3 className="text-xl font-bold gradient-text mb-3">ارفع فيديو للبدء</h3>
          <p className="text-muted-foreground">اختر ملف فيديو لبدء عملية الترجمة والتحرير</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-96 glass-effect border-l border-border overflow-y-auto animate-slide-in">
      {/* Language & Translation Section */}
      <div className="p-6 border-b border-border/50">
        <div className="glass-effect p-4 rounded-xl mb-4">
          <h3 className="text-xl font-bold mb-4 flex items-center gradient-text">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg mr-3 flex items-center justify-center">
              <Languages className="h-4 w-4 text-white" />
            </div>
            إعدادات الترجمة
          </h3>
        
          <div className="space-y-4">
            <div>
              <Label className="text-sm font-medium text-right">اللغة المصدر</Label>
              <Select value={sourceLanguage} onValueChange={setSourceLanguage}>
                <SelectTrigger className="w-full mt-2 glass-effect">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LANGUAGES.map(lang => (
                    <SelectItem key={lang.value} value={lang.value}>
                      {lang.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="text-sm font-medium text-right">اللغة المستهدفة</Label>
              <Select value={targetLanguage} onValueChange={setTargetLanguage}>
                <SelectTrigger className="w-full mt-2 glass-effect">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LANGUAGES.filter(l => l.value !== "auto").map(lang => (
                    <SelectItem key={lang.value} value={lang.value}>
                      {lang.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button 
              onClick={handleGenerateCaptions}
              disabled={generateCaptionsMutation.isPending}
              className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 font-medium neon-glow-cyan"
            >
              {generateCaptionsMutation.isPending ? (
                <>
                  <div className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full" />
                  جاري التوليد...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  توليد الترجمات
                </>
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Text Styling Section */}
      <div className="p-6 border-b border-border/50">
        <div className="glass-effect p-4 rounded-xl mb-4">
          <h3 className="text-xl font-bold mb-4 flex items-center gradient-text">
            <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg mr-3 flex items-center justify-center">
              <Type className="h-4 w-4 text-white" />
            </div>
            تنسيق النصوص
          </h3>
        
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm font-medium">نوع الخط</Label>
                <Select 
                  value={style?.fontFamily || "Inter"} 
                  onValueChange={(value) => handleStyleUpdate({ fontFamily: value })}
                >
                  <SelectTrigger className="w-full mt-2 glass-effect">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {FONT_FAMILIES.map(font => (
                      <SelectItem key={font.value} value={font.value}>
                        {font.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm font-medium">حجم الخط</Label>
                <Select 
                  value={style?.fontSize || "medium"} 
                  onValueChange={(value) => handleStyleUpdate({ fontSize: value })}
                >
                  <SelectTrigger className="w-full mt-2 glass-effect">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {FONT_SIZES.map(size => (
                      <SelectItem key={size.value} value={size.value}>
                        {size.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label className="text-sm font-medium">لون النص</Label>
              <div className="flex flex-wrap gap-2 mt-2">
                {TEXT_COLORS.map(color => (
                  <button
                    key={color}
                    className={`w-8 h-8 rounded-lg border-2 transition-all hover:scale-110 ${
                      style?.textColor === color ? 'border-primary neon-glow-blue' : 'border-border'
                    }`}
                    style={{ backgroundColor: color }}
                    onClick={() => handleStyleUpdate({ textColor: color })}
                  />
                ))}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <Button
                variant={style?.bold ? "default" : "outline"}
                size="sm"
                className="glass-effect"
                onClick={() => handleStyleUpdate({ bold: !style?.bold })}
              >
                <Bold className="mr-1 h-4 w-4" />
                غامق
              </Button>
              <Button
                variant={style?.italic ? "default" : "outline"}
                size="sm"
                className="glass-effect"
                onClick={() => handleStyleUpdate({ italic: !style?.italic })}
              >
                <Italic className="mr-1 h-4 w-4" />
                مائل
              </Button>
              <Button
                variant={style?.shadow ? "default" : "outline"}
                size="sm"
                className="glass-effect"
                onClick={() => handleStyleUpdate({ shadow: !style?.shadow })}
              >
                <Eye className="mr-1 h-4 w-4" />
                ظل
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <Button
                variant={style?.outline ? "default" : "outline"}
                size="sm"
                className="glass-effect"
                onClick={() => handleStyleUpdate({ outline: !style?.outline })}
              >
                <Palette className="mr-1 h-4 w-4" />
                إطار
              </Button>
              <Button
                variant={style?.glow ? "default" : "outline"}
                size="sm"
                className="glass-effect neon-glow-purple"
                onClick={() => handleStyleUpdate({ glow: !style?.glow })}
              >
                <Sparkles className="mr-1 h-4 w-4" />
                توهج
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Icons & Emojis Section */}
      <div className="p-6 border-b border-border/50">
        <div className="glass-effect p-4 rounded-xl mb-4">
          <h3 className="text-xl font-bold mb-4 flex items-center gradient-text">
            <div className="w-8 h-8 bg-gradient-to-br from-pink-500 to-orange-500 rounded-lg mr-3 flex items-center justify-center">
              <span className="text-lg">😊</span>
            </div>
            الرموز والإيموجي
          </h3>
          
          <div className="space-y-4">
            <div>
              <Label className="text-sm font-medium">إيموجي شائعة</Label>
              <div className="grid grid-cols-6 gap-2 mt-2">
                {EMOJIS.map(emoji => (
                  <button
                    key={emoji}
                    className="p-3 hover:bg-accent rounded-lg transition-all text-2xl glass-effect hover:scale-110 hover:neon-glow-pink"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Caption Positioning */}
      <div className="p-6">
        <div className="glass-effect p-4 rounded-xl">
          <h3 className="text-xl font-bold mb-4 flex items-center gradient-text">
            <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-teal-500 rounded-lg mr-3 flex items-center justify-center">
              <Move className="h-4 w-4 text-white" />
            </div>
            موضع الترجمة
          </h3>
          
          <div className="space-y-4">
            <div>
              <Label className="text-sm font-medium">الموضع العمودي</Label>
              <div className="grid grid-cols-3 gap-2 mt-2">
                {["top", "middle", "bottom"].map(position => (
                  <Button
                    key={position}
                    variant={style?.position === position ? "default" : "outline"}
                    size="sm"
                    className="glass-effect"
                    onClick={() => handleStyleUpdate({ position })}
                  >
                    {position === "top" ? "أعلى" : position === "middle" ? "وسط" : "أسفل"}
                  </Button>
                ))}
              </div>
            </div>

            <div>
              <Label className="text-sm font-medium">المحاذاة الأفقية</Label>
              <div className="grid grid-cols-3 gap-2 mt-2">
                <Button
                  variant={style?.alignment === "left" ? "default" : "outline"}
                  size="sm"
                  className="glass-effect"
                  onClick={() => handleStyleUpdate({ alignment: "left" })}
                >
                  <AlignLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant={style?.alignment === "center" ? "default" : "outline"}
                  size="sm"
                  className="glass-effect"
                  onClick={() => handleStyleUpdate({ alignment: "center" })}
                >
                  <AlignCenter className="h-4 w-4" />
                </Button>
                <Button
                  variant={style?.alignment === "right" ? "default" : "outline"}
                  size="sm"
                  className="glass-effect"
                  onClick={() => handleStyleUpdate({ alignment: "right" })}
                >
                  <AlignRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}