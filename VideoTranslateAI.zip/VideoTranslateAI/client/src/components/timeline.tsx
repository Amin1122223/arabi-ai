import { useState, useRef } from "react";
import { VideoProject, Caption } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Play, Pause, Square, Eye, Download } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface TimelineProps {
  project: VideoProject;
}

interface CaptionWithDisplay extends Caption {
  displayText: string;
}

export function Timeline({ project }: TimelineProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const timelineRef = useRef<HTMLDivElement>(null);

  const { data: captions = [] } = useQuery<CaptionWithDisplay[]>({
    queryKey: ["/api/videos", project.id, "captions"],
  });

  const totalDuration = project.duration || 60000; // Default to 60 seconds if no duration

  const handleTimelineClick = (e: React.MouseEvent) => {
    if (!timelineRef.current) return;
    
    const rect = timelineRef.current.getBoundingClientRect();
    const clickPosition = (e.clientX - rect.left) / rect.width;
    const newTime = clickPosition * totalDuration;
    setCurrentTime(newTime);
  };

  const formatTime = (milliseconds: number) => {
    const seconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getTimelineMarkers = () => {
    const markers = [];
    const markerCount = 5;
    for (let i = 0; i <= markerCount; i++) {
      const time = (i / markerCount) * totalDuration;
      markers.push(time);
    }
    return markers;
  };

  return (
    <div className="primary-800 border-t border-border p-4">
      <div className="max-w-7xl mx-auto">
        {/* Timeline Controls */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4">
            <Button 
              size="icon"
              variant="outline"
              onClick={() => setIsPlaying(!isPlaying)}
            >
              {isPlaying ? (
                <Pause className="h-4 w-4 text-accent-blue" />
              ) : (
                <Play className="h-4 w-4 text-accent-blue" />
              )}
            </Button>
            <Button size="icon" variant="outline">
              <Square className="h-4 w-4" />
            </Button>
            <span className="text-sm text-muted-foreground">
              {formatTime(currentTime)} / {formatTime(totalDuration)}
            </span>
          </div>

          <div className="flex items-center space-x-4">
            <Button variant="outline">
              <Eye className="mr-2 h-4 w-4" />
              Preview
            </Button>
            <Button className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600">
              <Download className="mr-2 h-4 w-4" />
              Export Video
            </Button>
          </div>
        </div>

        {/* Timeline Ruler */}
        <div className="primary-700 rounded-lg p-4">
          <div 
            ref={timelineRef}
            className="relative h-16 primary-600 rounded-lg overflow-hidden cursor-pointer"
            onClick={handleTimelineClick}
          >
            {/* Timeline track */}
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-cyan-500 opacity-20"></div>
            
            {/* Caption segments */}
            {captions.map((caption, index) => {
              const startPercent = (caption.startTime / totalDuration) * 100;
              const widthPercent = ((caption.endTime - caption.startTime) / totalDuration) * 100;
              const colors = ["bg-blue-500", "bg-purple-500", "bg-cyan-500"];
              const color = colors[index % colors.length];
              
              return (
                <div
                  key={caption.id}
                  className={`absolute top-2 h-3 ${color} rounded-sm opacity-80 hover:opacity-100 transition-opacity`}
                  style={{
                    left: `${startPercent}%`,
                    width: `${widthPercent}%`,
                  }}
                  title={caption.text}
                />
              );
            })}
            
            {/* Playhead */}
            <div 
              className="absolute top-0 bottom-0 w-0.5 bg-white shadow-lg z-10"
              style={{ left: `${(currentTime / totalDuration) * 100}%` }}
            >
              <div className="absolute -top-1 -left-2 w-4 h-4 bg-white rounded-full shadow-lg"></div>
            </div>
          </div>
          
          {/* Time markers */}
          <div className="flex justify-between mt-2 text-xs text-muted-foreground">
            {getTimelineMarkers().map((time, index) => (
              <span key={index}>{formatTime(time)}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
