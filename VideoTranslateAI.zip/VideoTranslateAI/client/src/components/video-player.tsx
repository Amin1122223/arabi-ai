import { useState, useRef, useEffect } from "react";
import { VideoProject, Caption } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Expand, Settings } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface VideoPlayerProps {
  project: VideoProject;
}

interface CaptionWithDisplay extends Caption {
  displayText: string;
}

export function VideoPlayer({ project }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [selectedLanguage, setSelectedLanguage] = useState("auto");
  
  // Check if this is a YouTube video
  const isYouTubeVideo = project.originalPath?.includes('youtube.com') || project.originalPath?.includes('youtu.be');
  
  // Extract YouTube video ID for embedding
  const getYouTubeVideoId = (url: string) => {
    try {
      const urlObj = new URL(url);
      if (urlObj.hostname.includes('youtube.com')) {
        return urlObj.searchParams.get('v') || '';
      } else if (urlObj.hostname.includes('youtu.be')) {
        return urlObj.pathname.slice(1);
      }
    } catch {
      return '';
    }
    return '';
  };

  const youtubeVideoId = isYouTubeVideo ? getYouTubeVideoId(project.originalPath) : '';

  const { data: captions = [] } = useQuery<CaptionWithDisplay[]>({
    queryKey: ["/api/videos", project.id, "captions", selectedLanguage],
    queryFn: async () => {
      const response = await fetch(`/api/videos/${project.id}/captions?language=${selectedLanguage}`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch captions");
      return response.json();
    },
  });

  const { data: style } = useQuery({
    queryKey: ["/api/videos", project.id, "style"],
    queryFn: async () => {
      const response = await fetch(`/api/videos/${project.id}/style`, {
        credentials: "include",
      });
      if (!response.ok) return null;
      return response.json();
    },
  });

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleTimeUpdate = () => {
      setCurrentTime(video.currentTime * 1000); // Convert to milliseconds
    };

    video.addEventListener("timeupdate", handleTimeUpdate);
    return () => video.removeEventListener("timeupdate", handleTimeUpdate);
  }, []);

  // Find current caption
  const currentCaption = captions.find(
    caption => currentTime >= caption.startTime && currentTime <= caption.endTime
  );

  const getTextStyle = () => {
    if (!style) return {};

    return {
      fontFamily: style?.fontFamily || "Arial",
      fontSize: style?.fontSize === "small" ? "14px" : 
                style?.fontSize === "medium" ? "18px" :
                style?.fontSize === "large" ? "24px" : "32px",
      color: style?.textColor || "#ffffff",
      fontWeight: style?.bold ? "bold" : "normal",
      fontStyle: style?.italic ? "italic" : "normal",
      textShadow: style?.shadow ? "2px 2px 4px rgba(0,0,0,0.8)" : "none",
      WebkitTextStroke: style?.outline ? "1px black" : "none",
      filter: style?.glow ? "drop-shadow(0 0 8px currentColor)" : "none",
    };
  };

  const getCaptionPosition = () => {
    if (!style) return "bottom-4 left-4 right-4";

    const vertical = style?.position === "top" ? "top-4" : 
                    style?.position === "middle" ? "top-1/2 -translate-y-1/2" : 
                    "bottom-4";
    
    return `${vertical} left-4 right-4`;
  };

  const getCaptionAlignment = () => {
    if (!style) return "text-center";
    
    return style?.alignment === "left" ? "text-left" :
           style?.alignment === "right" ? "text-right" :
           "text-center";
  };

  return (
    <div className="flex-1 bg-gray-900 rounded-xl overflow-hidden glass-effect">
      <div className="relative w-full h-full">
        {/* Real Video Player */}
        {isYouTubeVideo && youtubeVideoId ? (
          // YouTube iframe player
          <div className="w-full h-full">
            <iframe
              ref={iframeRef}
              width="100%"
              height="100%"
              src={`https://www.youtube.com/embed/${youtubeVideoId}?enablejsapi=1&origin=${window.location.origin}`}
              title="YouTube video player"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
              className="w-full h-full rounded-lg"
            />
          </div>
        ) : (
          // Standard video player for uploaded files
          <video
            ref={videoRef}
            className="w-full h-full object-contain bg-black rounded-lg"
            controls
            crossOrigin="anonymous"
          >
            <source src={`/api/videos/${project.id}/stream`} type="video/mp4" />
            متصفحك لا يدعم تشغيل الفيديو.
          </video>
        )}

        {/* Caption Overlay */}
        {currentCaption && (
          <div className={`absolute ${getCaptionPosition()}`}>
            <div 
              className="bg-black bg-opacity-80 backdrop-blur-sm rounded-lg p-4"
              style={{ backgroundColor: style?.backgroundColor }}
            >
              <p 
                className={`leading-relaxed ${getCaptionAlignment()}`}
                style={getTextStyle()}
              >
                {currentCaption.displayText}
              </p>
            </div>
          </div>
        )}

        {/* Video Controls Overlay */}
        <div className="absolute top-4 right-4">
          <div className="flex space-x-2">
            <Button 
              size="icon" 
              variant="ghost" 
              className="bg-black bg-opacity-50 hover:bg-opacity-70 text-white"
            >
              <Expand className="h-4 w-4" />
            </Button>
            <Button 
              size="icon" 
              variant="ghost" 
              className="bg-black bg-opacity-50 hover:bg-opacity-70 text-white"
            >
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
