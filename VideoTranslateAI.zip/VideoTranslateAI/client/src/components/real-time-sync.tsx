import { useState, useEffect, useRef, useCallback } from "react";
import { VideoProject, Caption } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Play, Pause, Volume2, VolumeX, BarChart3, 
  Mic, Languages, RefreshCw, Clock, Eye
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface RealTimeSyncProps {
  project: VideoProject;
  captions: Caption[];
  currentTime: number;
  isPlaying: boolean;
  onTimeUpdate: (time: number) => void;
}

interface AudioAnalysis {
  frequency: number[];
  volume: number;
  speechDetected: boolean;
}

export function RealTimeSync({ 
  project, 
  captions, 
  currentTime, 
  isPlaying,
  onTimeUpdate 
}: RealTimeSyncProps) {
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [analyzer, setAnalyzer] = useState<AnalyserNode | null>(null);
  const [audioData, setAudioData] = useState<AudioAnalysis>({
    frequency: [],
    volume: 0,
    speechDetected: false
  });
  const [syncOffset, setSyncOffset] = useState(0);
  const [autoSync, setAutoSync] = useState(true);
  const [visualMode, setVisualMode] = useState<'waveform' | 'spectrum'>('waveform');
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();

  // Check if this is a YouTube video
  const isYouTubeVideo = project.originalPath?.includes('youtube.com') || project.originalPath?.includes('youtu.be');
  
  const getYouTubeVideoId = (url: string) => {
    try {
      if (url.includes('youtu.be/')) {
        return url.split('youtu.be/')[1].split('?')[0].split('&')[0];
      } else if (url.includes('youtube.com/watch?v=')) {
        return url.split('v=')[1].split('&')[0];
      } else if (url.includes('youtube.com/embed/')) {
        return url.split('embed/')[1].split('?')[0];
      }
    } catch {
      return '';
    }
    return '';
  };

  const youtubeVideoId = isYouTubeVideo ? getYouTubeVideoId(project.originalPath) : '';

  // Initialize audio analysis
  useEffect(() => {
    if (!videoRef.current || isYouTubeVideo) return;

    const initAudioAnalysis = async () => {
      try {
        const context = new (window.AudioContext || (window as any).webkitAudioContext)();
        const analyserNode = context.createAnalyser();
        
        analyserNode.fftSize = 2048;
        analyserNode.smoothingTimeConstant = 0.8;
        
        const source = context.createMediaElementSource(videoRef.current!);
        source.connect(analyserNode);
        analyserNode.connect(context.destination);
        
        setAudioContext(context);
        setAnalyzer(analyserNode);
      } catch (error) {
        console.warn('Audio analysis not available:', error);
      }
    };

    initAudioAnalysis();

    return () => {
      if (audioContext) {
        audioContext.close();
      }
    };
  }, [project.id, isYouTubeVideo]);

  // Audio analysis loop
  const analyzeAudio = useCallback(() => {
    if (!analyzer) return;

    const bufferLength = analyzer.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    const frequencyArray = new Uint8Array(bufferLength);
    
    analyzer.getByteTimeDomainData(dataArray);
    analyzer.getByteFrequencyData(frequencyArray);

    // Calculate volume
    let sum = 0;
    for (let i = 0; i < bufferLength; i++) {
      const normalized = (dataArray[i] - 128) / 128;
      sum += normalized * normalized;
    }
    const volume = Math.sqrt(sum / bufferLength) * 100;

    // Detect speech (simple frequency analysis)
    const speechFreqRange = frequencyArray.slice(20, 80); // Human speech range roughly
    const speechLevel = speechFreqRange.reduce((a, b) => a + b, 0) / speechFreqRange.length;
    const speechDetected = speechLevel > 30 && volume > 5;

    setAudioData({
      frequency: Array.from(frequencyArray),
      volume,
      speechDetected
    });

    // Draw waveform/spectrum
    drawVisualization(dataArray, frequencyArray);

    if (isPlaying) {
      animationRef.current = requestAnimationFrame(analyzeAudio);
    }
  }, [analyzer, isPlaying, visualMode]);

  useEffect(() => {
    if (isPlaying && analyzer) {
      analyzeAudio();
    } else if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying, analyzer, analyzeAudio]);

  const drawVisualization = (timeData: Uint8Array, freqData: Uint8Array) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
    ctx.fillRect(0, 0, width, height);

    if (visualMode === 'waveform') {
      // Draw waveform
      ctx.lineWidth = 2;
      ctx.strokeStyle = '#00ff88';
      ctx.beginPath();

      const sliceWidth = width / timeData.length;
      let x = 0;

      for (let i = 0; i < timeData.length; i++) {
        const v = timeData[i] / 128.0;
        const y = v * height / 2;

        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }

        x += sliceWidth;
      }

      ctx.stroke();
    } else {
      // Draw frequency spectrum
      const barWidth = width / freqData.length;
      let x = 0;

      for (let i = 0; i < freqData.length; i++) {
        const barHeight = (freqData[i] / 255) * height;
        
        const hue = (i / freqData.length) * 360;
        ctx.fillStyle = `hsl(${hue}, 100%, 50%)`;
        ctx.fillRect(x, height - barHeight, barWidth, barHeight);

        x += barWidth;
      }
    }

    // Speech detection indicator
    if (audioData.speechDetected) {
      ctx.fillStyle = 'rgba(255, 0, 0, 0.3)';
      ctx.fillRect(0, 0, width, height);
      
      ctx.fillStyle = '#ff0000';
      ctx.font = '12px Arial';
      ctx.fillText('🎙️ SPEECH DETECTED', 10, 20);
    }
  };

  // Find current caption with sync offset
  const getCurrentCaption = () => {
    const adjustedTime = currentTime + syncOffset;
    return captions.find(
      caption => adjustedTime >= caption.startTime && adjustedTime <= caption.endTime
    );
  };

  // Auto-sync based on audio analysis
  useEffect(() => {
    if (!autoSync || !audioData.speechDetected) return;

    const currentCaption = getCurrentCaption();
    if (!currentCaption) return;

    // Simple auto-sync logic: if speech is detected but no caption is showing,
    // adjust the sync offset slightly
    const tolerance = 500; // 500ms tolerance
    const captionStart = currentCaption.startTime;
    const timeDiff = currentTime - captionStart;

    if (Math.abs(timeDiff) > tolerance) {
      const adjustment = timeDiff > 0 ? -100 : 100; // Small adjustment
      setSyncOffset(prev => prev + adjustment);
    }
  }, [audioData.speechDetected, currentTime, autoSync, captions]);

  const formatTime = (ms: number) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    const milliseconds = Math.floor((ms % 1000) / 10);
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}.${milliseconds.toString().padStart(2, '0')}`;
  };

  const currentCaption = getCurrentCaption();

  return (
    <div className="space-y-4">
      {/* Real-time Audio Visualization */}
      <Card className="glass-effect">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center justify-between">
            <div className="flex items-center">
              <BarChart3 className="w-4 h-4 mr-2" />
              تحليل الصوت المباشر
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant={visualMode === 'waveform' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setVisualMode('waveform')}
                className="text-xs"
              >
                موجة صوتية
              </Button>
              <Button
                variant={visualMode === 'spectrum' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setVisualMode('spectrum')}
                className="text-xs"
              >
                طيف ترددي
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* Audio Visualization Canvas */}
          <div className="relative">
            <canvas
              ref={canvasRef}
              width={400}
              height={100}
              className="w-full h-24 bg-black rounded border"
            />
            
            {/* Audio Level Indicator */}
            <div className="absolute top-2 right-2 flex items-center space-x-2">
              <Volume2 className="w-3 h-3 text-white" />
              <div className="w-16 h-2 bg-gray-700 rounded">
                <div 
                  className="h-full bg-green-500 rounded transition-all duration-100"
                  style={{ width: `${Math.min(audioData.volume, 100)}%` }}
                />
              </div>
              <span className="text-xs text-white">{Math.round(audioData.volume)}%</span>
            </div>

            {/* Speech Detection Badge */}
            {audioData.speechDetected && (
              <Badge className="absolute top-2 left-2 bg-red-500 text-white animate-pulse">
                <Mic className="w-3 h-3 mr-1" />
                كلام مكتشف
              </Badge>
            )}
          </div>

          {/* Sync Controls */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <RefreshCw className="w-4 h-4" />
                <span className="text-sm">مزامنة الترجمة</span>
              </div>
              <Button
                variant={autoSync ? "default" : "outline"}
                size="sm"
                onClick={() => setAutoSync(!autoSync)}
                className="text-xs"
              >
                {autoSync ? "تلقائي" : "يدوي"}
              </Button>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs">إزاحة المزامنة</span>
                <span className="text-xs font-mono">{syncOffset > 0 ? '+' : ''}{syncOffset}ms</span>
              </div>
              <Slider
                value={[syncOffset]}
                onValueChange={(value) => setSyncOffset(value[0])}
                min={-2000}
                max={2000}
                step={50}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>-2s</span>
                <span>0</span>
                <span>+2s</span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSyncOffset(prev => prev - 100)}
                className="text-xs"
              >
                -100ms
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSyncOffset(0)}
                className="text-xs"
              >
                إعادة تعيين
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSyncOffset(prev => prev + 100)}
                className="text-xs"
              >
                +100ms
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Current Caption with Sync Info */}
      {currentCaption && (
        <Card className="glass-effect border-blue-500/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center justify-between">
              <div className="flex items-center">
                <Languages className="w-4 h-4 mr-2" />
                الترجمة الحالية
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-3 h-3" />
                <span className="text-xs font-mono">
                  {formatTime(currentCaption.startTime)} - {formatTime(currentCaption.endTime)}
                </span>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="p-3 bg-black/30 rounded-lg">
                <p className="text-lg font-medium text-center">
                  {currentCaption.text}
                </p>
              </div>
              
              {/* Caption Progress */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>تقدم النص الحالي</span>
                  <span>
                    {Math.round(((currentTime + syncOffset - currentCaption.startTime) / 
                    (currentCaption.endTime - currentCaption.startTime)) * 100)}%
                  </span>
                </div>
                <div className="w-full h-2 bg-gray-700 rounded">
                  <div 
                    className="h-full bg-blue-500 rounded transition-all duration-100"
                    style={{ 
                      width: `${Math.max(0, Math.min(100, 
                        ((currentTime + syncOffset - currentCaption.startTime) / 
                        (currentCaption.endTime - currentCaption.startTime)) * 100
                      ))}%` 
                    }}
                  />
                </div>
              </div>

              {/* Sync Status */}
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center space-x-1">
                  <Eye className="w-3 h-3" />
                  <span>حالة المزامنة:</span>
                </div>
                <Badge 
                  variant={Math.abs(syncOffset) < 200 ? "default" : "destructive"}
                  className="text-xs"
                >
                  {Math.abs(syncOffset) < 200 ? "متزامن" : "يحتاج تعديل"}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Hidden video element for audio analysis */}
      {!isYouTubeVideo && (
        <video
          ref={videoRef}
          className="hidden"
          crossOrigin="anonymous"
          onTimeUpdate={() => {
            if (videoRef.current) {
              onTimeUpdate(videoRef.current.currentTime * 1000);
            }
          }}
        >
          <source src={`/api/videos/${project.id}/stream`} type="video/mp4" />
        </video>
      )}
    </div>
  );
}